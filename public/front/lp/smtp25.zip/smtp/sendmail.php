<?php
include 'library.php'; // include the library file
include "classes/class.phpmailer.php"; // include the class name
if(isset($_POST["email"])){
	$email = $_POST["email"];
	$name = $_POST["name"];
	$message = $_POST["message"];
	$conatct = $_POST["conatct"];
	$frmpagenames = $_POST["frmpagenames"];
	$frmips = $_POST["frmips"];
	if(empty($frmpagenames)){
		$frmpagenames="index.php";
	}
	$mail	= new PHPMailer; // call the class 
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; // authentication enabled
	$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
	$mail->Host = "smtp.gmail.com"; //Hostname of the mail server
	$mail->Port = 465; //Port of the SMTP like to be 25, 80, 465 or 587
	$mail->SMTPAuth = true; //Whether to use SMTP authentication
	$mail->Username = "seoservicesconsultantsofttrix@gmail.com"; //Username for SMTP authentication any valid email created in your domain
	$mail->Password = 'seoppc@506050'; //Password for SMTP authentication
	$mail->AddReplyTo("seoservicesconsultantsofttrix@gmail.com", "Softtrix seo services consultants"); //reply-to address
	$mail->SetFrom("adwordsppcexpertssofttrix@gmail.com", "AdwordsPPCExperts"); //From address of the mail
	// put your while loop here like below,
	$mail->Subject = "AdwordsPPCexperts: NEW MESSAGE"; //Subject od your mail
	$mail->AddAddress('sales@adwordsppcexpert.com'); //To address who will receive this email
	$mail->MsgHTML('<table width="100%" border="0" cellspacing="0" cellpadding="0" style="font-family: Open Sans, sans-serif; font-size:12px;color:#ffffff;line-height:20px;">
  <tr style="font-family: Open Sans, sans-serif;" >
    <td>&nbsp;</td>
    <td width="590" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td style="border:solid 1px #e5711b; background:#e5711b; padding:4px;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td bgcolor="#ffffff"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td height="47" style="text-align:center; padding-top:30px; padding-bottom:30px;" bgcolor="#ffffff"><img src="http://www.adwordsppcexpert.com/media/logo.jpg" border="0" alt="" /></td>
                    </tr>
                    <tr>
                      <td bgcolor="#ececec"  style="font-size:14px; color:#2a2a2a;font-family: Open Sans, sans-serif; font-weight:bold;  padding:8px 10px;">
                   Contact Us Email Recieved</td>
                    </tr>
                    <tr>
                      <td valign="top" bgcolor="#ffffff" style="padding:12px;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td height="26" style="font-size:16px;color:#e5711b;font-family: Open Sans, sans-serif; font-weight:bold;">Dear Admin</td>
                          </tr>
                          <tr>
                            <td style="font-size:13px; color:#484848; line-height:18px; padding-bottom:10px; ">'.$name.' contacted you with the following details.</td>
                          </tr>
                          <tr>
                            <td height="5"></td>
                          </tr>
                          <tr>
                            <td align="left"><table width="700" border="0" cellspacing="1" cellpadding="6" style="border:#1D7DC6 solid 1px;font-family: Open Sans, sans-serif;">
                                <tr  bgcolor="#ECECEC">
                                  <td colspan="2" style="border-top:#1D7DC6 solid 0px; font-size:14px; color:#e5711b; font-family: Open Sans, sans-serif; font-weight:bold; ">User Information</td>
                                </tr>
                                <tr  bgcolor="#ffffff">
                                  <td width="200" style="border-bottom:#1D7DC6 solid 1px;border-right:#1D7DC6 solid 1px; color:#484848; font-weight:bold;font-size:13px;font-family:Open Sans, sans-serif;">Name</td>
                                  <td width="470" style="border-bottom:#1D7DC6 solid 1px; color:#484848;font-size:13px;font-family:Open Sans, sans-serif;">'.$name.'</td>
                                </tr>
                                <tr  bgcolor="#ffffff">
                                  <td style="border-bottom:#1D7DC6 solid 1px;border-right:#1D7DC6 solid 1px;color:#484848; font-weight:bold;font-size:13px;font-family:Open Sans, sans-serif; ">Email Address</td>
                                  <td   style="border-bottom:#1D7DC6 solid 1px;color:#484848;font-size:13px;font-family:Open Sans, sans-serif;">'.$email.'</td>
                                </tr>
							    <tr  bgcolor="#ffffff">
                                  <td style="border-bottom:#1D7DC6 solid 1px;border-right:#1D7DC6 solid 1px;color:#484848; font-weight:bold;font-size:13px;font-family:Open Sans, sans-serif; ">Phone no</td>
                                  <td   style="border-bottom:#1D7DC6 solid 1px;color:#484848;font-size:13px;font-family:Open Sans, sans-serif;">'.$conatct.'</td>
                                </tr>	
                                <tr  bgcolor="#ffffff">
                                  <td  style="border-bottom:#1D7DC6 solid 1px;border-right:#1D7DC6 solid 1px;color:#484848; font-weight:bold;font-size:13px;font-family:Open Sans, sans-serif;">Message</td>
                                  <td   style="border-bottom:#1D7DC6 solid 1px;color:#484848;font-size:13px;font-family:Open Sans, sans-serif; ">'.$message.'</td>
                                </tr>
                                <tr  bgcolor="#ffffff">
                                  <td  style="border-bottom:#1D7DC6 solid 1px;border-right:#1D7DC6 solid 1px;color:#484848; font-weight:bold;font-size:13px;font-family:Open Sans, sans-serif;">Page Name</td>
                                  <td   style="border-bottom:#1D7DC6 solid 1px;color:#484848;font-size:13px;font-family:Open Sans, sans-serif; ">'.$frmpagenames.'</td>
                                </tr>
                                <tr  bgcolor="#ffffff">
                                  <td  style="border-right:#1D7DC6 solid 1px;color:#484848; font-weight:bold;font-size:13px;font-family:Open Sans, sans-serif;">IP</td>
                                  <td   style="color:#484848;font-size:13px;font-family:Open Sans, sans-serif; ">'.$frmips.'</td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr>
                            <td height="15"></td>
                          </tr>
                          <tr  style="color:#484848; font-size:14px; font-family: Open Sans, sans-serif;">
                            <td>Regards<br />
                              Customer Support Team<br />
							  Adwords PPC Experts
                              </td>
                          </tr>
                        </table></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
    <td>&nbsp;</td>
  </tr>
</table>'); //Put your body of the message you can place html code here
	//$mail->AddAttachment("images/asif18-logo.png"); //Attach a file here if any or comment this line, 
	$send = $mail->Send(); //Send the mails
	if($send){
		echo '0~<b style="color: green !important;">Mail Sent Successfully.</b>';
	}
	else{
		echo '1~<b>Sorry Please Try Again.</b>';
	}
}
?>
-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 16, 2018 at 10:09 AM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quick-love-dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `adminNotificationID` int(11) NOT NULL,
  `adminNotificationTitle` varchar(255) DEFAULT NULL,
  `adminNotificationMessage` text CHARACTER SET utf8mb4 NOT NULL,
  `adminNotificationUsers` text,
  `adminNotificationSentTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To send notification to users';

-- --------------------------------------------------------

--
-- Table structure for table `allowed_images_history`
--

CREATE TABLE `allowed_images_history` (
  `allowedImageID` bigint(20) NOT NULL,
  `allowedImageUserID` bigint(20) NOT NULL,
  `allowedImageModule` enum('DATING','JOBS') NOT NULL,
  `allowedImageCount` int(11) NOT NULL,
  `allowedImageDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage allowed images while completing jobs & dates';

-- --------------------------------------------------------

--
-- Table structure for table `block_users`
--

CREATE TABLE `block_users` (
  `userBlockId` bigint(20) NOT NULL,
  `userBlockUserId` bigint(20) NOT NULL,
  `userBlockFriendId` bigint(20) NOT NULL,
  `userBlockDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `call_history`
--

CREATE TABLE `call_history` (
  `callHistoryID` bigint(20) NOT NULL,
  `callHistoryModuleName` enum('FRIENDLY','DATING','PROVIDER') NOT NULL,
  `callSenderUserID` bigint(20) NOT NULL,
  `callRecieverUserID` bigint(20) NOT NULL,
  `userRoomName` varchar(100) DEFAULT NULL,
  `callInitiateTime` datetime NOT NULL,
  `callJoinedTime` datetime DEFAULT NULL,
  `callCompletedTime` datetime DEFAULT NULL,
  `callDuration` bigint(11) NOT NULL DEFAULT '0' COMMENT '(In Seconds)',
  `IsSenderCallReviewDone` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `IsRecieverCallReviewDone` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `senderCallReview` smallint(1) DEFAULT NULL,
  `recieverCallReview` smallint(1) DEFAULT NULL,
  `senderCallReviewMessage` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recieverCallReviewMessage` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senderCallReviewDateTime` datetime DEFAULT NULL,
  `recieverCallReviewDateTime` datetime DEFAULT NULL,
  `callSenderStatus` varchar(150) NOT NULL,
  `callStatus` enum('INITIATED','MISSED_CALL','STARTED','DECLINE_CALL','FINISHED') NOT NULL DEFAULT 'INITIATED'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user call history';

-- --------------------------------------------------------

--
-- Table structure for table `call_history_users`
--

CREATE TABLE `call_history_users` (
  `callHistoryUsersID` bigint(20) NOT NULL,
  `callHistoryID` bigint(20) NOT NULL,
  `isCallOwner` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `callUserID` bigint(20) NOT NULL COMMENT '(Other users ids)',
  `callUserAddedDate` datetime NOT NULL,
  `callUserTerminatedDate` datetime DEFAULT NULL,
  `callUserTotalDuration` bigint(20) NOT NULL DEFAULT '0' COMMENT '(In Seconds)',
  `callUserStatus` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage call history users';

-- --------------------------------------------------------

--
-- Table structure for table `call_review`
--

CREATE TABLE `call_review` (
  `callReviewID` bigint(20) NOT NULL,
  `callReviewUserID` bigint(20) NOT NULL,
  `callReviewCallHistoryID` bigint(20) NOT NULL,
  `callReviewRating` smallint(1) NOT NULL DEFAULT '0',
  `callReviewMessage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `callReviewDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage call reviews';

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `contactId` bigint(20) NOT NULL,
  `contactUserId` bigint(20) NOT NULL,
  `contactPhone` varchar(150) NOT NULL,
  `contactSubject` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactMessage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactDateTime` datetime NOT NULL,
  `isRepliedByAdmin` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `replyDateTime` datetime DEFAULT NULL,
  `replyMessage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `contentId` int(11) NOT NULL,
  `contentText` longtext CHARACTER SET utf8mb4 NOT NULL,
  `contentType` varchar(50) NOT NULL,
  `contentAddedDate` datetime NOT NULL,
  `contentModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='For content pages like Terms & Conditions, Privacy Policy etc..';

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`contentId`, `contentText`, `contentType`, `contentAddedDate`, `contentModifiedDate`) VALUES
(1, '<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">Privacy Policy<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">Last updated: February 23, 2018.<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">Quicklove (“we") owns Tenant connect (the "App"). This\npage informs you of our policies regarding the collection, use and disclosure\nof Personal Information we receive from users of our App.<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">We use your Personal Information only for providing and improving our\nservices to you. By using the App, you agree to the collection and use of\ninformation in accordance with this policy and in adherence of local laws and\nregulations.</span></p><p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="color: inherit; font-family: inherit; font-size: 38.5px; font-weight: bold;">__________________________________________</span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><b><span style="font-size:10.0pt;font-family:\n&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:Arial">Information Collection and\nUse<o:p></o:p></span></b></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">While using our App, we may ask you to provide us with certain\npersonally identifiable information that can be used to contact or identify\nyou. Personally identifiable information may include, but is not limited to\nyour name ("Personal Information").<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><b><span style="font-size:10.0pt;font-family:\n&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:Arial">Log Data<o:p></o:p></span></b></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">Like many other similar Apps of ours, we collect information whenever\nour app is used as follows ("Log Data").<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">We use:<o:p></o:p></span></p>\n\n<p class="MsoListParagraphCxSpFirst" style="margin-top:6.0pt;margin-right:0in;\nmargin-bottom:0in;margin-left:30.0pt;margin-bottom:.0001pt;mso-add-space:auto;\ntext-indent:-.25in;mso-line-height-alt:1.0pt;mso-list:l0 level1 lfo1"><!--[if !supportLists]--><span style="font-size:10.0pt;font-family:&quot;Arial&quot;,sans-serif;mso-fareast-font-family:\nArial">-<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n</span></span><!--[endif]--><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;\nmso-bidi-font-family:Arial">android.permission.RECORD_AUDIO; this permission is\nfor recording audio on end-users mobile android devices.<o:p></o:p></span></p>\n\n<p class="MsoListParagraphCxSpMiddle" style="margin-top:6.0pt;margin-right:0in;\nmargin-bottom:0in;margin-left:30.0pt;margin-bottom:.0001pt;mso-add-space:auto;\ntext-indent:-.25in;mso-line-height-alt:1.0pt;mso-list:l0 level1 lfo1"><!--[if !supportLists]--><span style="font-size:10.0pt;font-family:&quot;Arial&quot;,sans-serif;mso-fareast-font-family:\nArial">-<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n</span></span><!--[endif]--><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;\nmso-bidi-font-family:Arial">android.permission.READ_PHONE_STATE : this\npermission reads some vital situation of the phone like battery level\n,manufacturer and many device specific features <o:p></o:p></span></p>\n\n<p class="MsoListParagraphCxSpMiddle" style="margin-top:6.0pt;margin-right:0in;\nmargin-bottom:0in;margin-left:30.0pt;margin-bottom:.0001pt;mso-add-space:auto;\ntext-indent:-.25in;mso-line-height-alt:1.0pt;mso-list:l0 level1 lfo1"><!--[if !supportLists]--><span style="font-size:10.0pt;font-family:&quot;Arial&quot;,sans-serif;mso-fareast-font-family:\nArial">-<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n</span></span><!--[endif]--><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;\nmso-bidi-font-family:Arial">android.permission.GET_ACCOUNTS; is to verify if\nuser synced Google account in mobile, and generate the key value for each\nuser(each Google account<o:p></o:p></span></p>\n\n<p class="MsoListParagraphCxSpLast" style="margin-top:6.0pt;margin-right:0in;\nmargin-bottom:0in;margin-left:30.0pt;margin-bottom:.0001pt;mso-add-space:auto;\ntext-indent:-.25in;mso-line-height-alt:1.0pt;mso-list:l0 level1 lfo1"><!--[if !supportLists]--><span style="font-size:10.0pt;font-family:&quot;Arial&quot;,sans-serif;mso-fareast-font-family:\nArial">-<span style="font-variant-numeric: normal; font-variant-east-asian: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n</span></span><!--[endif]--><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;\nmso-bidi-font-family:Arial">android.permission.READ_CONTACTS ; this is used to\nread end user phone contacts<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">In addition, we may use third party services such as Google Analytics\nthat collect, monitor and analyze how activities and impression and usage by\nusers of this app and google wallet services for carrying out app orders and\nreceiving electronic payment in the google app store.<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><b><span style="font-size:10.0pt;font-family:\n&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:Arial">Communications</span></b><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial"><o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">We may use your Personal Information to contact you with newsletters,\nmarketing or promotional materials and other information that.<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><b><span style="font-size:10.0pt;font-family:\n&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:Arial">Security</span></b><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial"><o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">The security of your Personal Information is important to us, but\nremember that no method of transmission over the Internet, or method of\nelectronic storage, is 100% secure. While we strive to use commercially\nacceptable means to protect your Personal Information, we cannot guarantee its\nabsolute security.<b><o:p></o:p></b></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><b><span style="font-size:10.0pt;font-family:\n&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:Arial">Changes to This Privacy\nPolicy<o:p></o:p></span></b></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">This Privacy Policy is effective as of February 19, 2018 and will remain\nin effect except with respect to any changes in its provisions in the future,\nwhich will be in effect immediately after being posted on this page and a\nnotification given 30days prior to effective change.<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">We reserve the right to update or change our Privacy Policy at any time\nand you should check this Privacy Policy periodically. Your continued use of\nthe Service after we post any modifications to the Privacy Policy on this page\nwill constitute your acknowledgment of the modifications and your consent to\nabide and be bound by the modified Privacy Policy.<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><b><span style="font-size:10.0pt;font-family:\n&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:Arial">Contact Us<o:p></o:p></span></b></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">If you have any questions about this Privacy Policy, please contact us\nby sending us an e-mail at this address:<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><b><span style="font-size:10.0pt;font-family:\n&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:Arial">xxx@yyy.com<o:p></o:p></span></b></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><b><span style="font-size:10.0pt;font-family:\n&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:Arial">Contact Us<o:p></o:p></span></b></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">If you have any questions about this Privacy Policy, please contact us\nby sending us an e-mail at this address:<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">Las Vegas, Nevada. <o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">United States.<o:p></o:p></span></p>\n\n<p class="MsoNormal" style="margin-top:6.0pt;margin-right:0in;margin-bottom:0in;\nmargin-left:0in;margin-bottom:.0001pt;mso-line-height-alt:1.0pt"><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif;mso-bidi-font-family:\nArial">Email: xxx@xyz.com</span><span style="font-size:10.0pt;font-family:&quot;Agency FB&quot;,sans-serif"><o:p></o:p></span></p>', 'PRIVACY_POLICY', '2017-09-12 09:25:21', '2018-03-14 11:02:43');
INSERT INTO `content` (`contentId`, `contentText`, `contentType`, `contentAddedDate`, `contentModifiedDate`) VALUES
(2, '<div align="center"><span style="color: rgb(102, 102, 102); font-size: medium; font-family: inherit;">TERMS OF USE</span></div><div align="center"><font color="#666666" size="3">Quicklove</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">Version Date: February 23, 2018</font></div><div align="center"><font color="#666666" size="3">TERMS OF USE AGREEMENT</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">This Terms of Use Agreement (“Agreement”) constitutes a legally binding agreement made between you, whether personally or on behalf of an entity (“user” or “you”) and Quicklove Web and its APP (collectively, “Company” or “we” or “us” or “our”), concerning your access to and use of the Quicklove website located at www.quicklove.pro or Quicklove APP as well as any other media form, media channel, mobile website or mobile application related or connected thereto (collectively, the “Quicklove products”). Our Quicklove App enable users to communicate while trading products and services for a monetary value, (“Company Services”).&nbsp;</font></div><div align="center"><font color="#666666" size="3">"Supplemental terms and conditions or documents that may be posted on the Website and APP from time to time, are hereby expressly incorporated into this Agreement by reference".</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">Availability App and Website&nbsp;</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">When Quicklove intentions is to make Website and APP available worldwide, Quicklove App may however be made available to selected regions based on company’s strategy. Quicklove makes no representation that the Website or APP is appropriate or available in other locations other than where it is operated by Company. The information provided on the Website or APP is not intended for distribution to or use by any person or entity in any jurisdiction or country where such distribution or use would be contrary to law or regulation or which would subject Company to any registration requirement within such jurisdiction or country. Accordingly, those persons who choose to access the Website or APP from other locations do so on their own initiative and are solely responsible for compliance with local laws, if and to the extent local laws are applicable.&nbsp;</font></div><div align="center"><font color="#666666" size="3">All users who are minors in the jurisdiction in which they reside (generally under the age of 16) are not permitted to register for the Website, APP or use the Company Services.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">YOU ACCEPT AND AGREE TO BE BOUND BY THIS AGREEMENT BY ACKNOWLEDGING SUCH ACCEPTANCE DURING THE REGISTRATION PROCESS (IF APPLICABLE) AND ALSO BY CONTINUING TO USE THE WEBSITE AND APP. IF YOU DO NOT AGREE TO ABIDE BY THIS AGREEMENT, OR TO MODIFICATIONS THAT COMPANY MAY MAKE TO THIS AGREEMENT IN THE FUTURE, DO NOT USE OR ACCESS OR CONTINUE TO USE OR ACCESS THE COMPANY SERVICES OR THE WEBSITE.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">PURCHASES; PAYMENT</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">Company bills you through an online billing account for subscription to our App and/or services. You agree to pay Company all charges at the prices then in effect for the products you or other persons using your billing account may purchase, and you authorize Company to charge your chosen payment provider for any such purchases. You agree to make payment using that selected payment method. If you have ordered a product or service that is subject to recurring charges then you consent to our charging your payment method on a recurring basis, without requiring your prior approval from you for each recurring charge until such time as you cancel the applicable product or service. Company reserves the right to correct any errors or mistakes in pricing that it makes even if it has already requested or received payment. Sales tax will be added to the sales price of purchases as deemed required by Company. Company may change prices at any time. All payments shall be in US dollars (USD).</font></div><div align="center"><font color="#666666" size="3">All fees and expenses payable pursuant to this Agreement must be paid together with value added tax .All payment will be processed through PayPal.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">REFUND POLICY&nbsp;</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">We do not provide refund for subscription or unsatisfied usage of our App, we may consider refunding only to the extent required by law, for failed or unsatisfied products or services transactions in the App.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">MOBILE APPLICATION LICENSE</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">User License</font></div><div align="center"><font color="#666666" size="3">If you are accessing the Company Services via a mobile application, then Company grants you a revocable, non-exclusive, non-transferable, limited right to install and use the application on wireless handsets owned and controlled by you, and to access and use the application on such devices strictly in accordance with the terms and conditions of this license. You shall use the application strictly in accordance with the terms of this license and shall not: (a) decompile, reverse engineer, disassemble, attempt to derive the source code of, or decrypt the application; (b) make any modification, adaptation, improvement, enhancement, translation or derivative work from the application; (c) violate any applicable laws, rules or regulations in connection with your access or use of the application; (d) remove, alter or obscure any proprietary notice (including any notice of copyright or trademark) of Company or its affiliates, partners, suppliers or the licensors of the application; (e) use the application for any revenue generating endeavor, commercial enterprise, or other purpose for which it is not designed or intended; (f) make the application available over a network or other environment permitting access or use by multiple devices or users at the same time; (g) use the application for creating a product, service or software that is, directly or indirectly, competitive with or in any way a substitute for the application; (h) use the application to send automated queries to any website or to send any unsolicited commercial e-mail; or (i) use any proprietary information or interfaces of Company or other intellectual property of Company in the design, development, manufacture, licensing or distribution of any applications, accessories or devices for use with the application.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">Terms Applicable to Apple and Android Devices</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">The following terms apply when you use a mobile application obtained from either the Apple Store or Google Play to access the Company Services. You acknowledge that this Agreement is concluded between you and Company only, and not with Apple Inc. or Google, Inc. (each an “App Distributor”), and Company, not an App Distributor, is solely responsible for the Company application and the content thereof. (1) SCOPE OF LICENSE: The license granted to you for the Company application is limited to a non-transferable license to use the Company application on a device that utilizes the Apple iOS or Android operating system, as applicable, and in accordance with the usage rules set forth in the applicable App Distributor terms of service. (2) MAINTENANCE AND SUPPORT: Company is solely responsible for providing any maintenance and support services with respect to the Company application, as specified in this Agreement, or as required under applicable law. You acknowledge that each App Distributor has no obligation whatsoever to furnish any maintenance and support services with respect to the Company application. (3) WARRANTY: Company is solely responsible for any product warranties, whether express or implied by law, to the extent not effectively disclaimed. In the event of any failure of the Company application to conform to any applicable warranty, you may notify an App Distributor, and the App Distributor, in accordance with its terms and policies, may refund the purchase price, if any, paid for the Company application, and to the maximum extent permitted by applicable law, an App Distributor will have no other warranty obligation whatsoever with respect to the Company application, and any other claims, losses, liabilities, damages, costs or expenses attributable to any failure to conform to any warranty will be Company’s sole responsibility. (4) PRODUCT CLAIMS: You acknowledge that Company, not an App Distributor, is responsible for addressing any claims of yours or any third party relating to the Company application or your possession and/or use of the Company application, including, but not limited to: (i) product liability claims; (ii) any claim that the Company application fails to conform to any applicable legal or regulatory requirement; and (iii) claims arising under consumer protection or similar legislation. (5) INTELLECTUAL PROPERTY RIGHTS: You acknowledge that, in the event of any third party claim that the Company application or your possession and use of the Company application infringes a third party’s intellectual property rights, the App Distributor will not be responsible for the investigation, defense, settlement and discharge of any such intellectual property infringement claim. (6) LEGAL COMPLIANCE: You represent and warrant that (i) you are not located in a country that is subject to a U.S. government embargo, or that has been designated by the U.S. government as a “terrorist supporting” country; and (ii) you are not listed on any U.S. government list of prohibited or restricted parties. (7) THIRD PARTY TERMS OF AGREEMENT: You must comply with applicable third party terms of agreement when using the Company application, e.g., if you have a VoIP application, then you must not be in violation of their wireless data service agreement when using the Company application. (8) THIRD PARTY BENEFICIARY: Company and you acknowledge and agree that the App Distributors, and their subsidiaries, are third party beneficiaries of this Agreement, and that, upon your acceptance of the terms and conditions of this Agreement, each App Distributor will have the right (and will be deemed to have accepted the right) to enforce this Agreement against you as a third party beneficiary thereof.&nbsp; &nbsp;&nbsp;</font></div><div align="center"><font color="#666666" size="3">&nbsp;&nbsp;</font></div><div align="center"><font color="#666666" size="3">SOCIAL MEDIA</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">As part of the functionality of the Website and APP, you may link your account with online accounts you may have with third party service providers (each such account, a “Third Party Account”) by either: (i) providing your Third Party Account login information through the Website/APP; or (ii) allowing Company to access your Third Party Account, as is permitted under the applicable terms and conditions that govern your use of each Third Party Account. You represent that you are entitled to disclose your Third Party Account login information to Company and/or grant Company access to your Third Party Account (including, but not limited to, for use for the purposes described herein), without breach by you of any of the terms and conditions that govern your use of the applicable Third Party Account and without obligating Company to pay any fees or making Company subject to any usage limitations imposed by such third party service providers. By granting Company access to any Third Party Accounts, you understand that (i) Company may access, make available and store (if applicable) any content that you have provided to and stored in your Third Party Account (the “Social Network Content”) so that it is available on and through the Website/APP via your account, including without limitation any friend lists, and (ii) Company may submit and receive additional information to your Third Party Account to the extent you are notified when you link your account with the Third Party Account. Depending on the Third Party Accounts you choose and subject to the privacy settings that you have set in such Third Party Accounts, personally identifiable information that you post to your Third Party Accounts may be available on and through your account on the Website/APP. Please note that if a Third Party Account or associated service becomes unavailable or Company’s access to such Third Party Account is terminated by the third party service provider, then Social Network Content may no longer be available on and through the Website. You will have the ability to disable the connection between your account on the Website/APP and your Third Party Accounts at any time. PLEASE NOTE THAT YOUR RELATIONSHIP WITH THE THIRD PARTY SERVICE PROVIDERS ASSOCIATED WITH YOUR THIRD PARTY ACCOUNTS IS GOVERNED SOLELY BY YOUR AGREEMENT(S) WITH SUCH THIRD PARTY SERVICE PROVIDERS. Company makes no effort to review any Social Network Content for any purpose, including but not limited to, for accuracy, legality or non-infringement, and Company is not responsible for any Social Network Content. You acknowledge and agree that Company may access your e-mail address book associated with a Third Party Account and your contacts list stored on your mobile device or tablet computer solely for the purposes of identifying and informing you of those contacts who have also registered to use the Website/APP. At your request made via email to our email address listed below, or through your account settings (if applicable), Company will deactivate the connection between the Website/APP and your Third Party Account and delete any information stored on Company’s servers that was obtained through such Third Party Account, except the username and profile picture that become associated with your account.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">SUBMISSIONS</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">You acknowledge and agree that any questions, comments, suggestions, ideas, feedback or other information about the Website/App or the Company Services ("Submissions") provided by you to Company are non-confidential and Company (as well as any designee of Company) shall be entitled to the unrestricted use and dissemination of these Submissions for any purpose, commercial or otherwise, without acknowledgment or compensation to you.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">PROHIBITED ACTIVITIES</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">You may not access or use our App or Website for any other purpose other than that for which Company makes it available. The Website may not be used in connection with any commercial endeavors except those that are specifically endorsed or approved by Company. Prohibited activity includes, but is not limited to:</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">A.　attempting to bypass any measures of the Website designed to prevent or restrict access to the Website, or any portion of the Website</font></div><div align="center"><font color="#666666" size="3">B.　attempting to impersonate another user or person or using the username of another user</font></div><div align="center"><font color="#666666" size="3">C.　criminal or tortious activity</font></div><div align="center"><font color="#666666" size="3">D.　deciphering, decompiling, disassembling or reverse engineering any of the software comprising or in any way making up a part of the Website</font></div><div align="center"><font color="#666666" size="3">E.　deleting the copyright or other proprietary rights notice from any Website/App content</font></div><div align="center"><font color="#666666" size="3">F.　engaging in any automated use of the system, such as using any data mining, robots or similar data gathering and extraction tools</font></div><div align="center"><font color="#666666" size="3">G.　except as may be the result of standard search engine or Internet browser usage, using or launching, developing or distributing any automated system, including, without limitation, any spider, robot (or "bot"), cheat utility, scraper or offline reader that accesses the Website, or using or launching any unauthorized script or other software</font></div><div align="center"><font color="#666666" size="3">H.　harassing, annoying, intimidating or threatening any Company employees or agents engaged in providing any portion of the Company Services to you</font></div><div align="center"><font color="#666666" size="3">I.　interfering with, disrupting, or creating an undue burden on the Website/App or the networks or services connected to the Website/App</font></div><div align="center"><font color="#666666" size="3">J.　making any unauthorized use of the Company Services, including collecting usernames and/or email addresses of users by electronic or other means for the purpose of sending unsolicited email, or creating user accounts by automated means or under false pretenses</font></div><div align="center"><font color="#666666" size="3">K.　selling or otherwise transferring your profile</font></div><div align="center"><font color="#666666" size="3">L.　systematic retrieval of data or other content from the Website/App to create or compile, directly or indirectly, a collection, compilation, database or directory without written permission from Company</font></div><div align="center"><font color="#666666" size="3">M.　tricking, defrauding or misleading Company and other users, especially in any attempt to learn sensitive account information such as passwords</font></div><div align="center"><font color="#666666" size="3">N.　using any information obtained from the Website/App in order to harass, abuse, or harm another person</font></div><div align="center"><font color="#666666" size="3">O.　using the Company Services as part of any effort to compete with Company or to provide services as a service bureau</font></div><div align="center"><font color="#666666" size="3">P.　using the Website/App in a manner inconsistent with any and all applicable laws and regulations</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">INTELLECTUAL PROPERTY RIGHTS</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">The content on the Website and APP (“Company Content”) and the trademarks, service marks and logos contained therein (“Marks”) are owned by or licensed to Company, and are subject to copyright and other intellectual property rights under Ireland and foreign laws and international conventions. Company Content, includes, without limitation, all source code, databases, functionality, software, website designs, audio, video, text, photographs and graphics. All Company graphics, logos, designs, page headers, button icons, scripts and service names are registered trademarks, common law trademarks or trade dress of Company in the Ireland and/or other countries. Company\'s trademarks and trade dress may not be used, including as part of trademarks and/or as part of domain names, in connection with any product or service in any manner that is likely to cause confusion and may not be copied, imitated, or used, in whole or in part, without the prior written permission of the Company.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">Company Content on the Website/App is provided to you “AS IS” for your information and personal use only and may not be used, copied, reproduced, aggregated, distributed, transmitted, broadcast, displayed, sold, licensed, or otherwise exploited for any other purposes whatsoever without the prior written consent of the respective owners. Provided that you are eligible to use the Website/App, you are granted a limited license to access and use the Website/App and the Company Content and to download or print a copy of any portion of the Company Content to which you have properly gained access solely for your personal, non-commercial use. Company reserves all rights not expressly granted to you in and to the Website/App and Company Content and Marks.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">THIRD PARTY WEBSITES AND CONTENT</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">The Website contains (or you may be sent through the Website or the Company Services) links to other websites ("Third Party Websites") as well as articles, photographs, text, graphics, pictures, designs, music, sound, video, information, applications, software and other content or items belonging to or originating from third parties (the "Third Party Content"). Such Third Party Websites and Third Party Content are not investigated, monitored or checked for accuracy, appropriateness, or completeness by us, and we are not responsible for any Third Party Websites accessed through the Website or any Third Party Content posted on, available through or installed from the Website, including the content, accuracy, offensiveness, opinions, reliability, privacy practices or other policies of or contained in the Third Party Websites or the Third Party Content. Inclusion of, linking to or permitting the use or installation of any Third Party Website or any Third Party Content does not imply approval or endorsement thereof by us. If you decide to leave the Website and access the Third Party Websites or to use or install any Third Party Content, you do so at your own risk and you should be aware that our terms and policies no longer govern. You should review the applicable terms and policies, including privacy and data gathering practices, of any website to which you navigate from the Website or relating to any applications you use or install from the Website. Any purchases you make through Third Party Websites will be through other websites and from other companies, and Company takes no responsibility whatsoever in relation to such purchases which are exclusively between you and the applicable third party.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">SITE MANAGEMENT</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">Company reserves the right but does not have the obligation to:</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">A.　monitor the Website and APP for violations of this Agreement;</font></div><div align="center"><font color="#666666" size="3">B.　take appropriate legal action against anyone who, in Company’s sole discretion, violates this Agreement, including without limitation, reporting such user to law enforcement authorities;</font></div><div align="center"><font color="#666666" size="3">C.　in Company’s sole discretion and without limitation, refuse, restrict access to or availability of, or disable (to the extent technologically feasible) any user’s contribution or any portion thereof that may violate this Agreement or any Company policy;</font></div><div align="center"><font color="#666666" size="3">D.　in Company’s sole discretion and without limitation, notice or liability to remove from the Website or otherwise disable all files and content that are excessive in size or are in any way burdensome to Company’s systems;</font></div><div align="center"><font color="#666666" size="3">E.　otherwise manage the Website in a manner designed to protect the rights and property of Company and others and to facilitate the proper functioning of the Website.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">PRIVACY POLICY</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">We care about the privacy of our users. Please review the Company Privacy Policy. By using the Website/App or Company Services, you are consenting to have your personal data transferred to and processed in Ireland. By using the Website or the Company Services, you are consenting to the terms of our Privacy Policy.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">TERM AND TERMINATION</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">This Agreement shall remain in full force and effect while you use the Website/App or are otherwise a user or member of the Website/App, as applicable. You may terminate your use or participation at any time, for any reason, by following the instructions for terminating user accounts in your account settings, if available, or by contacting us using the contact information below.&nbsp;</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">WITHOUT LIMITING ANY OTHER PROVISION OF THIS AGREEMENT, COMPANY RESERVES THE RIGHT TO, IN COMPANY’S SOLE DISCRETION AND WITHOUT NOTICE OR LIABILITY, DENY ACCESS TO AND USE OF THE WEBSITE/APP AND THE COMPANY SERVICES, TO ANY PERSON FOR ANY REASON OR FOR NO REASON AT ALL, INCLUDING WITHOUT LIMITATION FOR BREACH OF ANY REPRESENTATION, WARRANTY OR COVENANT CONTAINED IN THIS AGREEMENT, OR OF ANY APPLICABLE LAW OR REGULATION, AND COMPANY MAY TERMINATE YOUR USE OR PARTICIPATION IN THE WEBSITE/APP AND THE COMPANY SERVICES, DELETE YOUR PROFILE AND ANY CONTENT OR INFORMATION THAT YOU HAVE POSTED AT ANY TIME, WITHOUT WARNING, IN COMPANY’S SOLE DISCRETION.&nbsp;</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">In order to protect the integrity of the Website/App and Company Services, Company reserves the right at any time in its sole discretion to block certain IP addresses from accessing the Website/App and Company Services.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">Any provisions of this Agreement that, in order to fulfill the purposes of such provisions, need to survive the termination or expiration of this Agreement, shall be deemed to survive for as long as necessary to fulfill such purposes.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">YOU UNDERSTAND THAT CERTAIN STATES ALLOW YOU TO CANCEL THIS AGREEMENT, WITHOUT ANY PENALTY OR OBLIGATION, AT ANY TIME PRIOR TO MIDNIGHT OF COMPANY’S THIRD BUSINESS DAY FOLLOWING THE DATE OF THIS AGREEMENT, EXCLUDING SUNDAYS AND HOLIDAYS.&nbsp; TO CANCEL, CALL A COMPANY CUSTOMER CARE REPRESENTATIVE DURING NORMAL BUSINESS HOURS USING THE CONTACT INFORMATION LISTING BELOW IN THIS AGREEMENT OR BY ACCESSING YOUR ACCOUNT SETTINGS.&nbsp; THIS SECTION APPLIES ONLY TO INDIVIDUALS RESIDING IN STATES WITH SUCH LAWS.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">If Company terminates or suspends your account for any reason, you are prohibited from registering and creating a new account under your name, a fake or borrowed name, or the name of any third party, even if you may be acting on behalf of the third party. In addition to terminating or suspending your account, Company reserves the right to take appropriate legal action, including without limitation pursuing civil, criminal, and injunctive redress.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">MODIFICATIONS</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">To Agreement</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">Company may modify this Agreement from time to time. Any and all changes to this Agreement will be posted on the Website/App and revisions will be indicated by date. You agree to be bound to any changes to this Agreement when you use the Company Services after any such modification becomes effective. Company may also, in its discretion, choose to alert all users with whom it maintains email information of such modifications by means of an email to their most recently provided email address. It is therefore important that you regularly review this Agreement and keep your contact information current in your account settings to ensure you are informed of changes. You agree that you will periodically check the Website/App for updates to this Agreement and you will read the messages we send you to inform you of any changes. Modifications to this Agreement shall be effective after posting.&nbsp;</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">To Services</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">Company reserves the right at any time to modify or discontinue, temporarily or permanently, the Company Services (or any part thereof) with or without notice. You agree that Company shall not be liable to you or to any third party for any modification, suspension or discontinuance of the Company Services.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">DISPUTES</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">Between Users</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">If there is a dispute between users of the Website/App, or between users and any third party, you understand and agree that Company is under no obligation to become involved. In the event that you have a dispute with one or more other users, you hereby release Company, its officers, employees, agents and successors in rights from claims, demands and damages (actual and consequential) of every kind or nature, known or unknown, suspected and unsuspected, disclosed and undisclosed, arising out of or in any way related to such disputes and/or the Company Services.&nbsp;</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">With Company</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">A.&nbsp; &nbsp; &nbsp; &nbsp; Governing Law; Jurisdiction. This Agreement and all aspects of the Website/App and Company Services shall be governed by and construed in accordance with the internal laws of Nevada, United States, without regard to conflict of law provisions. With respect to any disputes or claims, parties hereby agree to resolve any dispute that may arise in the course of usage of this App and Website only through arbitration, and therefore waive all the right to a jury in any trial or hearing.</font></div><div align="center"><font color="#666666" size="3">B.&nbsp; &nbsp; &nbsp; Informal Resolution. To expedite resolution and control the cost of any dispute, controversy or claim related to this Agreement ("Dispute"), you and Company agree to first attempt to negotiate any Dispute (except those Disputes expressly provided below) informally for at least 120 days before initiating any arbitration or court proceeding. Such informal negotiations commence upon written notice from one person to the other.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">C.&nbsp; &nbsp; &nbsp; &nbsp;Binding Arbitration. If you and Company are unable to resolve a Dispute through informal negotiations, either you or Company may elect to have the Dispute (except those Disputes expressly excluded below) finally and exclusively resolved by binding arbitration. Any election to arbitrate by one party shall be final and binding on the other. All arbitration in this agreement, whether domestic or international, will be governed by the Arbitration Act 2010.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">D.&nbsp; &nbsp; &nbsp;Restrictions. You and Company agree that any arbitration shall be limited to the Dispute between Company and you individually. To the full extent permitted by law, (1) no arbitration shall be joined with any other; (2) there is no right or authority for any Dispute to be arbitrated on a class-action basis or to utilize class action procedures; and (3) there is no right or authority for any Dispute to be brought in a purported representative capacity on behalf of the general public or any other persons.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">E.&nbsp; &nbsp; &nbsp;Exceptions to Informal Negotiations and Arbitration. You and Company agree that the following Disputes are not subject to the above provisions concerning informal negotiations and binding arbitration: (1) any Disputes seeking to enforce or protect, or concerning the validity of any of your or Company’s intellectual property rights; (2) any Dispute related to, or arising from, allegations of theft, piracy, invasion of privacy or unauthorized use; and (3) any claim for injunctive relief. If this Section is found to be illegal or unenforceable then neither you nor Company will elect to arbitrate any Dispute falling within that portion of this Section found to be illegal or unenforceable and such Dispute shall be decided by a court of competent jurisdiction within the courts listed for jurisdiction above, and you and Company agree to submit to the personal jurisdiction of that court.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">CORRECTIONS</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">Occasionally there may be information on the Website/App that contains typographical errors, inaccuracies or omissions that may relate to service descriptions, pricing, availability, and various other information. Company reserves the right to correct any errors, inaccuracies or omissions and to change or update the information at any time, without prior notice.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">DISCLAIMERS</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">Company cannot control the nature of all of the content available on the Website/App. By operating the Website/App, Company does not represent or imply that Company endorses any blogs, contributions or other content available on or linked to by the Website/App, including without limitation content hosted on third party websites or provided by third party applications, or that Company believes contributions, blogs or other content to be accurate, useful or non-harmful. We do not control and are not responsible for unlawful or otherwise objectionable content you may encounter on the Website/App or in connection with any contributions. The Company is not responsible for the conduct, whether online or offline, of any user of the Website/App or Company Services.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">YOU AGREE THAT YOUR USE OF THE WEBSITE/APP AND COMPANY SERVICES WILL BE AT YOUR SOLE RISK. TO THE FULLEST EXTENT PERMITTED BY LAW, COMPANY, ITS OFFICERS, DIRECTORS, EMPLOYEES, AND AGENTS DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, IN CONNECTION WITH THE WEBSITE/APP AND THE COMPANY SERVICES AND YOUR USE THEREOF, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. COMPANY MAKES NO WARRANTIES OR REPRESENTATIONS ABOUT THE ACCURACY OR COMPLETENESS OF THE APP/WEBSITE’S CONTENT OR THE CONTENT OF ANY WEBSITES LINKED TO THIS APP/WEBSITE AND ASSUMES NO LIABILITY OR RESPONSIBILITY FOR ANY (A) ERRORS, MISTAKES, OR INACCURACIES OF CONTENT AND MATERIALS, (B) PERSONAL INJURY OR PROPERTY DAMAGE, OF ANY NATURE WHATSOEVER, RESULTING FROM YOUR ACCESS TO AND USE OF OUR WEBSITE/APP, (C) ANY UNAUTHORIZED ACCESS TO OR USE OF OUR SECURE SERVERS AND/OR ANY AND ALL PERSONAL INFORMATION AND/OR FINANCIAL INFORMATION STORED THEREIN, (D) ANY INTERRUPTION OR CESSATION OF TRANSMISSION TO OR FROM THE WEBSITE/APP OR COMPANY SERVICES, (E) ANY BUGS, VIRUSES, TROJAN HORSES, OR THE LIKE WHICH MAY BE TRANSMITTED TO OR THROUGH THE WEBSITE/APP BY ANY THIRD PARTY, AND/OR (F) ANY ERRORS OR OMISSIONS IN ANY CONTENT AND MATERIALS OR FOR ANY LOSS OR DAMAGE OF ANY KIND INCURRED AS A RESULT OF THE USE OF ANY CONTENT POSTED, TRANSMITTED, OR OTHERWISE MADE AVAILABLE VIA THE WEBSITE/APP. COMPANY DOES NOT WARRANT, ENDORSE, GUARANTEE, OR ASSUME RESPONSIBILITY FOR ANY PRODUCT OR SERVICE ADVERTISED OR OFFERED BY A THIRD PARTY THROUGH THE WEBSITE/APP OR ANY HYPERLINKED WEBSITE OR FEATURED IN ANY BANNER OR OTHER ADVERTISING, AND COMPANY WILL NOT BE A PARTY TO OR IN ANY WAY BE RESPONSIBLE FOR MONITORING ANY TRANSACTION BETWEEN YOU AND THIRD-PARTY PROVIDERS OF PRODUCTS OR SERVICES. AS WITH THE PURCHASE OF A PRODUCT OR SERVICE THROUGH ANY MEDIUM OR IN ANY ENVIRONMENT, YOU SHOULD USE YOUR BEST JUDGMENT AND EXERCISE CAUTION WHERE APPROPRIATE.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">LIMITATIONS OF LIABILITY</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">IN NO EVENT SHALL COMPANY OR ITS DIRECTORS, EMPLOYEES, OR AGENTS BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY DIRECT, INDIRECT, CONSEQUENTIAL, EXEMPLARY, INCIDENTAL, SPECIAL OR PUNITIVE DAMAGES, INCLUDING LOST PROFIT, LOST REVENUE, LOSS OF DATA OR OTHER DAMAGES ARISING FROM YOUR USE OF THE WEBSITE/APP OR COMPANY SERVICES, EVEN IF COMPANY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. NOTWITHSTANDING ANYTHING TO THE CONTRARY CONTAINED HEREIN, COMPANY’S LIABILITY TO YOU FOR ANY CAUSE WHATSOEVER AND REGARDLESS OF THE FORM OF THE ACTION, WILL AT ALL TIMES BE LIMITED TO THE AMOUNT PAID, IF ANY, BY YOU TO COMPANY FOR THE COMPANY SERVICES DURING THE PERIOD OF 30DAYS PRIOR TO ANY CAUSE OF ACTION ARISING.</font></div><div align="center"><font color="#666666" size="3">QUICKLOVE IS NOT RESPONSIBLE FOR ANY PRODUCTS OR SERVICE WARRANTIES EXCHANGED IN THE APP ITSELF.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">CERTAIN STATE LAWS DO NOT ALLOW LIMITATIONS ON IMPLIED WARRANTIES OR THE EXCLUSION OR LIMITATION OF CERTAIN DAMAGES. IF THESE LAWS APPLY TO YOU, SOME OR ALL OF THE ABOVE DISCLAIMERS OR LIMITATIONS MAY NOT APPLY TO YOU, AND YOU MAY HAVE ADDITIONAL RIGHTS.s&nbsp;&nbsp;</font></div><div align="center"><font color="#666666" size="3">&nbsp;&nbsp;</font></div><div align="center"><font color="#666666" size="3">INDEMNITY&nbsp;</font></div><div align="center"><font color="#666666" size="3">You agree to defend, indemnify and hold Company, its subsidiaries, and affiliates, and their respective officers, agents, partners and employees, harmless from and against, any loss, damage, liability, claim, or demand, including reasonable attorneys’ fees and expenses, made by any third party due to or arising out of your contributed content, use of the Company Services, and/or arising from a breach of this Agreement and/or any breach of your representations and warranties set forth above. Notwithstanding the foregoing, Company reserves the right, at your expense, to assume the exclusive defense and control of any matter for which you are required to indemnify Company, and you agree to cooperate, at your expense, with Company’s defense of such claims. Company will use reasonable efforts to notify you of any such claim, action, or proceeding which is subject to this indemnification upon becoming aware of it.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">&nbsp;&nbsp;</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">NOTICES&nbsp;</font></div><div align="center"><font color="#666666" size="3">Except as explicitly stated otherwise, any notices given to Company shall be given by email to the address listed in the contact information below. Any notices given to you shall be given to the email address you provided during the registration process, or such other address as each party may specify. Notice shall be deemed to be given seventy-two (72) hours after the email is sent, unless the sending party is notified that the email address is invalid. We may also choose to send notices by regular mail.</font></div><div align="center"><font color="#666666" size="3">&nbsp;&nbsp;</font></div><div align="center"><font color="#666666" size="3">USER DATA</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">Our Website/App will maintain certain data that you transfer to the Website/App for the purpose of the performance of the Company Services, as well as data relating to your use of the Company Services. Although we perform regular routine backups of data, you are primarily responsible for all data that you have transferred or that relates to any activity you have undertaken using the Company Services.&nbsp; You agree that Company shall have no liability to you for any loss or corruption of any such data, and you hereby waive any right of action against Company arising from any such loss or corruption of such data.</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">ELECTRONIC CONTRACTING</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">Your use of the Company Services includes the ability to enter into agreements and/or to make transactions electronically. YOU ACKNOWLEDGE THAT YOUR ELECTRONIC SUBMISSIONS CONSTITUTE YOUR AGREEMENT AND INTENT TO BE BOUND BY AND TO PAY FOR SUCH AGREEMENTS AND TRANSACTIONS. YOUR AGREEMENT AND INTENT TO BE BOUND BY ELECTRONIC SUBMISSIONS APPLIES TO ALL RECORDS RELATING TO ALL TRANSACTIONS YOU ENTER INTO RELATING TO THE COMPANY SERVICES, INCLUDING NOTICES OF CANCELLATION, POLICIES, CONTRACTS, AND APPLICATIONS. In order to access and retain your electronic records, you may be required to have certain hardware and software, which are your sole responsibility.</font></div><div align="center"><font color="#666666" size="3">&nbsp;&nbsp;</font></div><div align="center"><font color="#666666" size="3">MISCELLANEOUS</font></div><div align="center"><font color="#666666" size="3">&nbsp;</font></div><div align="center"><font color="#666666" size="3">This Agreement constitutes the entire agreement between you and Company regarding the use of the Company Services. The failure of Company to exercise or enforce any right or provision of this Agreement shall not operate as a waiver of such right or provision. The section titles in this Agreement are for convenience only and have no legal or contractual effect. This Agreement operates to the fullest extent permissible by law. This Agreement and your account may not be assigned by you without our express written consent. Company may assign any or all of its rights and obligations to others at any time. Company shall not be responsible or liable for any loss, damage, delay or failure to act caused by any cause beyond Company\'s reasonable control.&nbsp; If any provision or part of a provision of this Agreement is unlawful, void or unenforceable, that provision or part of the provision is deemed severable from this Agreement and does not affect the validity and enforceability of any remaining provisions. There is no joint venture, partnership, employment or agency relationship created between you and Company as a result of this Agreement or use of the Website/App and Company Services. Upon Company’s request, you will furnish Company any documentation, substantiation or releases necessary to verify your compliance with this Agreement. You agree that this Agreement will not be construed against Company by virtue of having drafted them. You hereby waive any and all defenses you may have based on the electronic form of this Agreement and the lack of signing by the parties hereto to execute this Agreement.</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">CONTACT US</font></div><div align="center"><font color="#666666" size="3">In order to give feedback, regarding the company’s services, or to receive further information regarding use of the company services, please contact Company as set forth below by providing us with the following details:</font></div><div align="center"><font color="#666666" size="3">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</font></div><div align="center"><font color="#666666" size="3">i.<span style="white-space: pre;">	</span>Name&nbsp;</font></div><div align="center"><font color="#666666" size="3">ii.<span style="white-space: pre;">	</span>Subject</font></div><div align="center"><font color="#666666" size="3">iii.<span style="white-space: pre;">	</span>Email</font></div><div align="center"><font color="#666666" size="3">iv.<span style="white-space: pre;">	</span>Message</font></div><div align="center"><font color="#666666" size="3"><br></font></div><div align="center"><font color="#666666" size="3">Las Vegas, Nevada.&nbsp;</font></div><div align="center"><font color="#666666" size="3">United States.&nbsp;</font></div><div align="center"><font color="#666666" size="3">Email: xxx@yyy.com</font></div><div align="center"><span style="color: rgb(102, 102, 102); font-family: inherit; font-size: medium;">Phone: xxx-xxxx-xxxx</span></div><div><span style="color: rgb(102, 102, 102); font-family: inherit; font-size: medium;"><br></span></div>', 'TERMS_CONDITIONS', '2017-09-12 09:25:21', '2018-03-14 12:06:00');
INSERT INTO `content` (`contentId`, `contentText`, `contentType`, `contentAddedDate`, `contentModifiedDate`) VALUES
(3, '<div>In the current World of Emerging Media and Informational Platforms, we find ourselves in the Era of Overabundance of Content. Delivering in this way a sense of disconnection from reality.&nbsp;</div><div><br></div><div>The human bond that is so essential for our existence can not fade away. This hyperconsumption of content has lead to a Society that Communicates, but does not Connect. Unity, as a constant fuel for success, is generated only when we embrace our nature to bond, transparently, with a sense of positive faith.</div><div><br></div><div>For the overcrowded cities where some feel isolated, and all the entrepreneurs connecting from different corners of the World, we present to you Quicklove: Real Connections on Real Time. Here you\'ll be finding people loving what you do.</div><div><br></div><div>On behalf of the QL Team, we Thank You for downloading this App, and we ask a small favor:</div><div><br></div><div>This App is built by us, but designed by you.&nbsp;</div><div><br></div><div>Help us with your comments and suggestions. We want to keep improving it for you.</div><div><br></div><div>Remember, we are all in this together.</div><div><br></div><div>Thank you and enjoy&nbsp; ; )</div><div><br></div><div>Navil Lertora</div><div>CEO</div><div>Quicklove (c)</div>', 'ABOUT_US', '2017-09-12 08:20:20', '2018-02-02 06:57:18'),
(4, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'BECOME_PROVIDER', '2017-11-16 10:27:24', '2017-11-16 12:47:42'),
(5, 'Cancellation Policy If a cancellation for the upcoming work is made in a timeframe of 4 days or more prior to the job date, there will be No Cancelation Fee. If the cancelation of the upcoming work is made in a timeframe of 3 days or less prior to the job date, there will be a 25% cancelation fee. If the cancelation of the upcoming work is made in a timeframe of 1 day prior to the job date, there will be a 35% cancelation fee. Note-In all these cases, the App will still receive 10% of the total agreed payment from both sides. If this situation occurs, and an Instant Payment is done, the company will not be hold accountable if the worker does not want to give back those funds. We advise, in that situation, to set another date to carry on with the original agreed job.', 'CANCELLATION_POLICY', '2017-12-14 13:24:17', '2017-12-14 13:14:55'),
(6, '<div><span style="font-family: inherit;">A RED FLAG Notification is for cases that include activities involving Sex Related Crimes, Stolen Property, Damaged / Unfixed Property and Illegal Trade or Drug Activities.&nbsp;</span></div><div><br></div><div>Giving any user a Red Flag will open an Investigation Case that could permanently block them from Quicklove.</div><div><br></div><div>Also notice that the constant use (abuse) of this option could potentially generate a block to the User that \'overuses\' this Option.</div><div><br></div><div>Have available Videos or/and Photographic evidence of the alleged crime/damage. If you believe that a more immediate action is necessary, then please contact the Police.</div><div><br></div><div>You can Report a RED FLAG by going to a User\'s Profile, and tap on the Menu on the upper right corner of the screen (3 dots).</div><div><br></div><div>QL Team.</div>', 'RED_FLAG', '2018-02-21 08:21:17', '2018-03-01 07:34:37');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `countryId` int(11) NOT NULL,
  `countryCode` varchar(30) NOT NULL,
  `countryName` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`countryId`, `countryCode`, `countryName`) VALUES
(1, 'AF', 'Afghanistan'),
(2, 'AL', 'Albania'),
(3, 'DZ', 'Algeria'),
(4, 'AS', 'American Samoa'),
(5, 'AD', 'Andorra'),
(6, 'AO', 'Angola'),
(7, 'AI', 'Anguilla'),
(8, 'AQ', 'Antarctica'),
(9, 'AG', 'Antigua And Barbuda'),
(10, 'AR', 'Argentina'),
(11, 'AM', 'Armenia'),
(12, 'AW', 'Aruba'),
(13, 'AU', 'Australia'),
(14, 'AT', 'Austria'),
(15, 'AZ', 'Azerbaijan'),
(16, 'BS', 'Bahamas The'),
(17, 'BH', 'Bahrain'),
(18, 'BD', 'Bangladesh'),
(19, 'BB', 'Barbados'),
(20, 'BY', 'Belarus'),
(21, 'BE', 'Belgium'),
(22, 'BZ', 'Belize'),
(23, 'BJ', 'Benin'),
(24, 'BM', 'Bermuda'),
(25, 'BT', 'Bhutan'),
(26, 'BO', 'Bolivia'),
(27, 'BA', 'Bosnia and Herzegovina'),
(28, 'BW', 'Botswana'),
(29, 'BV', 'Bouvet Island'),
(30, 'BR', 'Brazil'),
(31, 'IO', 'British Indian Ocean Territory'),
(32, 'BN', 'Brunei'),
(33, 'BG', 'Bulgaria'),
(34, 'BF', 'Burkina Faso'),
(35, 'BI', 'Burundi'),
(36, 'KH', 'Cambodia'),
(37, 'CM', 'Cameroon'),
(38, 'CA', 'Canada'),
(39, 'CV', 'Cape Verde'),
(40, 'KY', 'Cayman Islands'),
(41, 'CF', 'Central African Republic'),
(42, 'TD', 'Chad'),
(43, 'CL', 'Chile'),
(44, 'CN', 'China'),
(45, 'CX', 'Christmas Island'),
(46, 'CC', 'Cocos (Keeling) Islands'),
(47, 'CO', 'Colombia'),
(48, 'KM', 'Comoros'),
(49, 'CG', 'Congo'),
(50, 'CD', 'Congo The Democratic Republic Of The'),
(51, 'CK', 'Cook Islands'),
(52, 'CR', 'Costa Rica'),
(53, 'CI', 'Cote D\'Ivoire (Ivory Coast)'),
(54, 'HR', 'Croatia (Hrvatska)'),
(55, 'CU', 'Cuba'),
(56, 'CY', 'Cyprus'),
(57, 'CZ', 'Czech Republic'),
(58, 'DK', 'Denmark'),
(59, 'DJ', 'Djibouti'),
(60, 'DM', 'Dominica'),
(61, 'DO', 'Dominican Republic'),
(62, 'TP', 'East Timor'),
(63, 'EC', 'Ecuador'),
(64, 'EG', 'Egypt'),
(65, 'SV', 'El Salvador'),
(66, 'GQ', 'Equatorial Guinea'),
(67, 'ER', 'Eritrea'),
(68, 'EE', 'Estonia'),
(69, 'ET', 'Ethiopia'),
(70, 'XA', 'External Territories of Australia'),
(71, 'FK', 'Falkland Islands'),
(72, 'FO', 'Faroe Islands'),
(73, 'FJ', 'Fiji Islands'),
(74, 'FI', 'Finland'),
(75, 'FR', 'France'),
(76, 'GF', 'French Guiana'),
(77, 'PF', 'French Polynesia'),
(78, 'TF', 'French Southern Territories'),
(79, 'GA', 'Gabon'),
(80, 'GM', 'Gambia The'),
(81, 'GE', 'Georgia'),
(82, 'DE', 'Germany'),
(83, 'GH', 'Ghana'),
(84, 'GI', 'Gibraltar'),
(85, 'GR', 'Greece'),
(86, 'GL', 'Greenland'),
(87, 'GD', 'Grenada'),
(88, 'GP', 'Guadeloupe'),
(89, 'GU', 'Guam'),
(90, 'GT', 'Guatemala'),
(91, 'XU', 'Guernsey and Alderney'),
(92, 'GN', 'Guinea'),
(93, 'GW', 'Guinea-Bissau'),
(94, 'GY', 'Guyana'),
(95, 'HT', 'Haiti'),
(96, 'HM', 'Heard and McDonald Islands'),
(97, 'HN', 'Honduras'),
(98, 'HK', 'Hong Kong S.A.R.'),
(99, 'HU', 'Hungary'),
(100, 'IS', 'Iceland'),
(101, 'IN', 'India'),
(102, 'ID', 'Indonesia'),
(103, 'IR', 'Iran'),
(104, 'IQ', 'Iraq'),
(105, 'IE', 'Ireland'),
(106, 'IL', 'Israel'),
(107, 'IT', 'Italy'),
(108, 'JM', 'Jamaica'),
(109, 'JP', 'Japan'),
(110, 'XJ', 'Jersey'),
(111, 'JO', 'Jordan'),
(112, 'KZ', 'Kazakhstan'),
(113, 'KE', 'Kenya'),
(114, 'KI', 'Kiribati'),
(115, 'KP', 'Korea North'),
(116, 'KR', 'Korea South'),
(117, 'KW', 'Kuwait'),
(118, 'KG', 'Kyrgyzstan'),
(119, 'LA', 'Laos'),
(120, 'LV', 'Latvia'),
(121, 'LB', 'Lebanon'),
(122, 'LS', 'Lesotho'),
(123, 'LR', 'Liberia'),
(124, 'LY', 'Libya'),
(125, 'LI', 'Liechtenstein'),
(126, 'LT', 'Lithuania'),
(127, 'LU', 'Luxembourg'),
(128, 'MO', 'Macau S.A.R.'),
(129, 'MK', 'Macedonia'),
(130, 'MG', 'Madagascar'),
(131, 'MW', 'Malawi'),
(132, 'MY', 'Malaysia'),
(133, 'MV', 'Maldives'),
(134, 'ML', 'Mali'),
(135, 'MT', 'Malta'),
(136, 'XM', 'Man (Isle of)'),
(137, 'MH', 'Marshall Islands'),
(138, 'MQ', 'Martinique'),
(139, 'MR', 'Mauritania'),
(140, 'MU', 'Mauritius'),
(141, 'YT', 'Mayotte'),
(142, 'MX', 'Mexico'),
(143, 'FM', 'Micronesia'),
(144, 'MD', 'Moldova'),
(145, 'MC', 'Monaco'),
(146, 'MN', 'Mongolia'),
(147, 'MS', 'Montserrat'),
(148, 'MA', 'Morocco'),
(149, 'MZ', 'Mozambique'),
(150, 'MM', 'Myanmar'),
(151, 'NA', 'Namibia'),
(152, 'NR', 'Nauru'),
(153, 'NP', 'Nepal'),
(154, 'AN', 'Netherlands Antilles'),
(155, 'NL', 'Netherlands The'),
(156, 'NC', 'New Caledonia'),
(157, 'NZ', 'New Zealand'),
(158, 'NI', 'Nicaragua'),
(159, 'NE', 'Niger'),
(160, 'NG', 'Nigeria'),
(161, 'NU', 'Niue'),
(162, 'NF', 'Norfolk Island'),
(163, 'MP', 'Northern Mariana Islands'),
(164, 'NO', 'Norway'),
(165, 'OM', 'Oman'),
(166, 'PK', 'Pakistan'),
(167, 'PW', 'Palau'),
(168, 'PS', 'Palestinian Territory Occupied'),
(169, 'PA', 'Panama'),
(170, 'PG', 'Papua new Guinea'),
(171, 'PY', 'Paraguay'),
(172, 'PE', 'Peru'),
(173, 'PH', 'Philippines'),
(174, 'PN', 'Pitcairn Island'),
(175, 'PL', 'Poland'),
(176, 'PT', 'Portugal'),
(177, 'PR', 'Puerto Rico'),
(178, 'QA', 'Qatar'),
(179, 'RE', 'Reunion'),
(180, 'RO', 'Romania'),
(181, 'RU', 'Russia'),
(182, 'RW', 'Rwanda'),
(183, 'SH', 'Saint Helena'),
(184, 'KN', 'Saint Kitts And Nevis'),
(185, 'LC', 'Saint Lucia'),
(186, 'PM', 'Saint Pierre and Miquelon'),
(187, 'VC', 'Saint Vincent And The Grenadines'),
(188, 'WS', 'Samoa'),
(189, 'SM', 'San Marino'),
(190, 'ST', 'Sao Tome and Principe'),
(191, 'SA', 'Saudi Arabia'),
(192, 'SN', 'Senegal'),
(193, 'RS', 'Serbia'),
(194, 'SC', 'Seychelles'),
(195, 'SL', 'Sierra Leone'),
(196, 'SG', 'Singapore'),
(197, 'SK', 'Slovakia'),
(198, 'SI', 'Slovenia'),
(199, 'XG', 'Smaller Territories of the UK'),
(200, 'SB', 'Solomon Islands'),
(201, 'SO', 'Somalia'),
(202, 'ZA', 'South Africa'),
(203, 'GS', 'South Georgia'),
(204, 'SS', 'South Sudan'),
(205, 'ES', 'Spain'),
(206, 'LK', 'Sri Lanka'),
(207, 'SD', 'Sudan'),
(208, 'SR', 'Suriname'),
(209, 'SJ', 'Svalbard And Jan Mayen Islands'),
(210, 'SZ', 'Swaziland'),
(211, 'SE', 'Sweden'),
(212, 'CH', 'Switzerland'),
(213, 'SY', 'Syria'),
(214, 'TW', 'Taiwan'),
(215, 'TJ', 'Tajikistan'),
(216, 'TZ', 'Tanzania'),
(217, 'TH', 'Thailand'),
(218, 'TG', 'Togo'),
(219, 'TK', 'Tokelau'),
(220, 'TO', 'Tonga'),
(221, 'TT', 'Trinidad And Tobago'),
(222, 'TN', 'Tunisia'),
(223, 'TR', 'Turkey'),
(224, 'TM', 'Turkmenistan'),
(225, 'TC', 'Turks And Caicos Islands'),
(226, 'TV', 'Tuvalu'),
(227, 'UG', 'Uganda'),
(228, 'UA', 'Ukraine'),
(229, 'AE', 'United Arab Emirates'),
(230, 'GB', 'United Kingdom'),
(231, 'US', 'United States'),
(232, 'UM', 'United States Minor Outlying Islands'),
(233, 'UY', 'Uruguay'),
(234, 'UZ', 'Uzbekistan'),
(235, 'VU', 'Vanuatu'),
(236, 'VA', 'Vatican City State (Holy See)'),
(237, 'VE', 'Venezuela'),
(238, 'VN', 'Vietnam'),
(239, 'VG', 'Virgin Islands (British)'),
(240, 'VI', 'Virgin Islands (US)'),
(241, 'WF', 'Wallis And Futuna Islands'),
(242, 'EH', 'Western Sahara'),
(243, 'YE', 'Yemen'),
(244, 'YU', 'Yugoslavia'),
(245, 'ZM', 'Zambia'),
(246, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `dating_review`
--

CREATE TABLE `dating_review` (
  `datingReviewID` bigint(20) NOT NULL,
  `datingReviewUserID` bigint(20) NOT NULL,
  `datingReviewDateScheduleID` bigint(20) NOT NULL,
  `datingReviewRating` smallint(1) NOT NULL DEFAULT '0',
  `datingReviewMessage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `datingReviewDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage dating reviews';

-- --------------------------------------------------------

--
-- Table structure for table `deal_breaker_preferences`
--

CREATE TABLE `deal_breaker_preferences` (
  `dealBreakerPreferenceId` bigint(20) NOT NULL,
  `dealBreakerPreferenceUserId` bigint(20) NOT NULL,
  `dealBreakerPreferenceType` enum('FRIENDLY','DATING','PROVIDER') NOT NULL,
  `dealBreakerPreferenceText` varchar(250) NOT NULL,
  `dealBreakerPreferenceCreatedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user deal breaker preferences';

-- --------------------------------------------------------

--
-- Table structure for table `describe_preferences`
--

CREATE TABLE `describe_preferences` (
  `describePreferenceId` bigint(20) NOT NULL,
  `describePreferenceUserId` bigint(20) NOT NULL,
  `describePreferenceType` enum('FRIENDLY','DATING','PROVIDER') NOT NULL,
  `describePreferenceParentID` bigint(20) NOT NULL,
  `describePreferenceCreatedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user describe preferences';

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `masterFriendId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL COMMENT '(Sender Id)',
  `friendId` bigint(20) NOT NULL COMMENT '(Reciever Id)',
  `friendStatus` enum('PENDING','ACCEPT','REJECT') NOT NULL DEFAULT 'PENDING',
  `friendNote` varchar(255) DEFAULT NULL,
  `friendRequestSentTime` datetime NOT NULL,
  `friendRequestResponseTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user friends';

-- --------------------------------------------------------

--
-- Table structure for table `hold_amounts`
--

CREATE TABLE `hold_amounts` (
  `holdAmountID` bigint(20) NOT NULL,
  `holdAmountUserID` bigint(20) NOT NULL,
  `holdAmountJobID` bigint(20) NOT NULL,
  `holdAmount` float(7,2) NOT NULL,
  `holdAmountStatus` enum('ON_HOLD','PAID','CANCELLED','OTHER') NOT NULL DEFAULT 'ON_HOLD',
  `holdAmountDateTime` datetime NOT NULL,
  `holdAmountResponseDateTime` datetime DEFAULT NULL,
  `holdAmountExtraParams` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user hold amount';

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `jobID` bigint(20) NOT NULL,
  `jobCustomID` varchar(150) DEFAULT NULL,
  `jobHirerUserID` bigint(20) NOT NULL COMMENT '(Sender)',
  `jobProviderUserID` bigint(20) NOT NULL COMMENT '(Receiver)',
  `jobTitle` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `jobDescprition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `jobMode` enum('ONLINE','LOCAL') NOT NULL,
  `jobAddress` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `jobLatitude` varchar(150) DEFAULT NULL,
  `jobLongitude` varchar(150) DEFAULT NULL,
  `jobStartDate` date DEFAULT NULL,
  `jobEndDate` date DEFAULT NULL,
  `jobPaymentMethod` enum('ADVANCE','FROZEN','ADVANCE_AND_FROZEN') NOT NULL,
  `jobAgreedAmount` int(11) NOT NULL COMMENT '(In USD)',
  `jobAdvanceAmount` int(11) DEFAULT NULL,
  `jobMilestoneAmountTotal` int(11) DEFAULT NULL,
  `jobType` enum('FIXED','MILESTONES') NOT NULL,
  `jobNoOfMilestones` smallint(6) NOT NULL DEFAULT '0',
  `jobHireDateTime` datetime NOT NULL,
  `jobGlobalStatus` enum('PENDING','COMPLETED','CANCELED','DISPUTE','MUTUALLY_CANCELED') NOT NULL DEFAULT 'PENDING',
  `jobAcceptStatus` enum('PENDING','ACCEPT','REJECTED') NOT NULL DEFAULT 'PENDING' COMMENT '(Provider Accept Status)',
  `jobReview` float DEFAULT NULL,
  `jobDisputed` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `jobDisputeStatus` enum('NONE','PENDING','ADMIN_REJECTED','ADMIN_COMPLETED','USER_COMPLETED') NOT NULL DEFAULT 'NONE',
  `jobAcceptDateTime` datetime DEFAULT NULL,
  `jobCancelReason` text,
  `jobResponseDateTime` datetime DEFAULT NULL COMMENT '(After complete Or cancel job)'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user jobs';

-- --------------------------------------------------------

--
-- Table structure for table `jobs_payment_distribution`
--

CREATE TABLE `jobs_payment_distribution` (
  `jobPaymentDistributionID` bigint(20) NOT NULL,
  `jobParentID` bigint(20) NOT NULL,
  `jobHirerQlFeesPercent` float NOT NULL,
  `jobProviderQlFeesPercent` float NOT NULL,
  `jobHirerQlFeesAmount` float NOT NULL COMMENT '(Hirer QL Fees Amount Deduction)',
  `jobProviderQlFeesAmount` float NOT NULL COMMENT '(Provider QL Fees Amount Deduction)',
  `jobHirerAdvanceAmount` float DEFAULT NULL,
  `jobProviderAdvanceAmount` float DEFAULT NULL,
  `jobHirerMilestoneAmount` float DEFAULT NULL,
  `jobProviderMilestoneAmount` float DEFAULT NULL,
  `jobTotalAgreedAmount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage jobs payment distribution';

-- --------------------------------------------------------

--
-- Table structure for table `jobs_review`
--

CREATE TABLE `jobs_review` (
  `jobReviewID` bigint(20) NOT NULL,
  `jobReviewUserID` bigint(20) NOT NULL,
  `jobReviewParentID` bigint(20) NOT NULL,
  `jobReviewRating` float NOT NULL,
  `jobReviewMessage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `jobReviewDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage jobs review';

-- --------------------------------------------------------

--
-- Table structure for table `job_cancel`
--

CREATE TABLE `job_cancel` (
  `jobCancelID` bigint(20) NOT NULL,
  `jobCancelUserID` bigint(20) NOT NULL,
  `jobParentID` bigint(20) NOT NULL,
  `jobCancelStatus` enum('INITIATED','CANCELLED','COMPLETED','OTHER') NOT NULL DEFAULT 'INITIATED',
  `jobCancelReason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `jobCancelDatetime` datetime NOT NULL,
  `jobCancelResponseDatetime` datetime DEFAULT NULL COMMENT '(For Cancel OR Completed)',
  `jobCancelFeesPercent` float NOT NULL,
  `jobCancelFeesAmount` float NOT NULL,
  `jobPaidAmount` float DEFAULT NULL,
  `jobCancelRemainingAmount` float DEFAULT NULL COMMENT '(Hold amount on QL, still not paid)',
  `jobCancelAdminRefundAmount` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage cancel jobs';

-- --------------------------------------------------------

--
-- Table structure for table `job_disputes`
--

CREATE TABLE `job_disputes` (
  `jobDisputeID` bigint(20) NOT NULL,
  `jobDisputeUserID` bigint(20) NOT NULL,
  `jobParentID` bigint(20) NOT NULL,
  `jobDisputeStatus` enum('PENDING','ADMIN_REJECTED','ADMIN_COMPLETED','USER_COMPLETED') NOT NULL DEFAULT 'PENDING',
  `jobDisputeReason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `jobDisputeDateTime` datetime NOT NULL,
  `jobDisputeResponseDateTime` datetime DEFAULT NULL,
  `jobDisputePaidAmount` float DEFAULT NULL,
  `jobDisputeRemainingAmount` float DEFAULT NULL,
  `jobDisputeHireRefundAmount` float DEFAULT NULL,
  `jobDisputeProviderRefundAmount` float DEFAULT NULL,
  `jobDisputeExtraParams` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage all job disputes';

-- --------------------------------------------------------

--
-- Table structure for table `looking_preferences`
--

CREATE TABLE `looking_preferences` (
  `lookingPreferenceId` bigint(20) NOT NULL,
  `lookingPreferenceUserId` bigint(20) NOT NULL,
  `lookingPreferenceType` enum('FRIENDLY','DATING','PROVIDER') NOT NULL,
  `lookingPreferenceParentID` bigint(20) NOT NULL,
  `lookingPreferenceCreatedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user looking preferences';

-- --------------------------------------------------------

--
-- Table structure for table `milestones`
--

CREATE TABLE `milestones` (
  `milestoneID` bigint(20) NOT NULL,
  `milestoneJobID` bigint(20) NOT NULL,
  `milestoneTitle` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `milestoneAmount` int(11) NOT NULL,
  `milestoneStatus` enum('PENDING','PAID') NOT NULL DEFAULT 'PENDING',
  `milestoneDateTime` datetime NOT NULL,
  `milestonePaidDateTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user jobs milestones';

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notificationId` bigint(20) NOT NULL,
  `notificationUserId` bigint(20) NOT NULL COMMENT '(Sender ID)',
  `notificationFriendId` bigint(20) NOT NULL COMMENT '(Reciever ID)',
  `notificationType` varchar(150) NOT NULL,
  `callScheduleModuleID` bigint(20) DEFAULT NULL,
  `callHistoryModuleID` bigint(20) DEFAULT NULL,
  `dateScheduleModuleID` bigint(20) DEFAULT NULL,
  `friendModuleId` bigint(20) DEFAULT NULL,
  `jobModuleID` bigint(20) DEFAULT NULL,
  `orderModuleID` bigint(20) DEFAULT NULL,
  `reportModuleID` bigint(20) DEFAULT NULL,
  `txnModuleID` bigint(20) DEFAULT NULL,
  `contactModuleId` bigint(20) DEFAULT NULL,
  `notificationMessage` text NOT NULL,
  `notificationModule` enum('FRIENDLY','DATING','PROVIDER','GLOBAL') NOT NULL DEFAULT 'FRIENDLY',
  `actionStatus` varchar(100) DEFAULT NULL,
  `notificationParams` text,
  `notificationSentTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage all app notifications';

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderID` bigint(20) NOT NULL,
  `orderCustomID` varchar(150) NOT NULL,
  `orderUserID` bigint(20) NOT NULL COMMENT '(Buyer)',
  `orderProductOwnerUserID` bigint(20) NOT NULL COMMENT '(Seller)',
  `orderTotalAmount` int(11) NOT NULL,
  `orderProviderAmount` float NOT NULL,
  `orderQLFeesPercent` float NOT NULL DEFAULT '8',
  `orderQLFeesAmount` float NOT NULL COMMENT '(8 % QL Fees)',
  `orderStatus` enum('PENDING','COMPLETED') NOT NULL DEFAULT 'PENDING',
  `orderFullName` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderContactNo` varchar(150) DEFAULT NULL,
  `orderShippingAddress` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `orderLandmark` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderCity` varchar(100) DEFAULT NULL,
  `orderState` varchar(150) DEFAULT NULL,
  `orderCountry` varchar(150) DEFAULT NULL,
  `orderZipCode` varchar(100) DEFAULT NULL,
  `orderLatitude` varchar(150) DEFAULT NULL,
  `orderLongitude` varchar(150) DEFAULT NULL,
  `orderDateTime` datetime NOT NULL,
  `orderPaymentGatewayAmount` float DEFAULT NULL COMMENT '(From Stripe Payment Gateway)',
  `orderWalletAmount` float DEFAULT NULL COMMENT '(From Quick Love Wallet)',
  `orderPaymentDateTime` datetime DEFAULT NULL,
  `orderPaymentStatus` enum('PENDING','COMPLETED','FAILED') NOT NULL DEFAULT 'PENDING',
  `orderPaymentTxnID` text,
  `orderPaymentResponse` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage product orders';

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `orderParentID` bigint(20) NOT NULL,
  `orderProductID` bigint(20) NOT NULL,
  `orderProductUserID` bigint(20) NOT NULL COMMENT '(Product Owner ID)',
  `orderProductName` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderProductPrice` int(11) NOT NULL,
  `orderProductDescprition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `orderProductOriginalImages` text,
  `orderProductThumbnailImages` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage order products';

-- --------------------------------------------------------

--
-- Table structure for table `preferences`
--

CREATE TABLE `preferences` (
  `preferenceID` bigint(20) NOT NULL,
  `preferenceName` varchar(150) NOT NULL,
  `preferenceType` smallint(1) NOT NULL COMMENT '0 = Describe you, 1 = Looking you',
  `preferenceModuleType` enum('FRIENDLY','DATING','PROVIDER') NOT NULL,
  `preferenceCreatedDate` datetime NOT NULL,
  `preferenceModifyDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `preferences`
--

INSERT INTO `preferences` (`preferenceID`, `preferenceName`, `preferenceType`, `preferenceModuleType`, `preferenceCreatedDate`, `preferenceModifyDate`) VALUES
(63, 'Amiable', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(64, 'Amiable', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(65, 'Compassionate', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(66, 'Compassionate', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(67, 'Considerate', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(68, 'Considerate', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(69, 'Courageous', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(70, 'Courageous', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(71, 'Courteous', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(72, 'Courteous', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(73, 'Empathetic', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(74, 'Empathetic', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(75, 'Exuberant', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(76, 'Exuberant', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(77, 'Frank', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(78, 'Frank', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(79, 'Generous', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(80, 'Generous', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(81, 'Gregarious', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(82, 'Gregarious', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(83, 'Impartial', 0, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(84, 'Impartial', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(85, 'Passionate', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(86, 'Passionate', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(87, 'Persistent', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(88, 'Persistent', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(89, 'Philosophical', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(90, 'Philosophical', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(91, 'Sensible', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(92, 'Sensible', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(93, 'Sincere', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(94, 'Sincere', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(95, 'Witty', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(96, 'Witty', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(97, 'Adaptable', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(98, 'Adaptable', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(99, 'Adventurous', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(100, 'Adventurous', 1, 'FRIENDLY', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(101, 'Affectionate', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(102, 'Affectionate', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(103, 'Broad-minded', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(104, 'Broad-minded', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(105, 'Calm', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(106, 'Calm', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(107, 'Careful', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(108, 'Careful', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(109, 'Charming', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(110, 'Charming', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(111, 'Determined', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(112, 'Determined', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(113, 'Diligent', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(114, 'Diligent', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(115, 'Dynamic', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(116, 'Dynamic', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(117, 'Easygoing', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(118, 'Easygoing', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(119, 'Emotional', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(120, 'Emotional', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(121, 'Energetic', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(122, 'Energetic', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(123, 'Fair-minded', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(124, 'Fair-minded', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(125, 'Faithful', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(126, 'Faithful', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(127, 'Funny', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(128, 'Funny', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(129, 'Gentle', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(130, 'Gentle', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(131, 'Loving', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(132, 'Loving', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(133, 'Loyal', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(134, 'Loyal', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(135, 'Modest', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(136, 'Modest', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(137, 'Powerful', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(138, 'Powerful', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(139, 'Quick-witted', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(140, 'Quick-witted', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(141, 'Sensible', 0, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(142, 'Sensible', 1, 'DATING', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(264, 'Thoughtful', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(265, 'Thoughtful', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(304, 'Versatile', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(305, 'Versatile', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(306, 'Pro-active', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(307, 'Pro-active', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(308, 'Pioneering', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(309, 'Pioneering', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(310, 'Optimistic', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(311, 'Optimistic', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(312, 'Independent', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(313, 'Independent', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(342, 'Imaginative', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(343, 'Imaginative', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(344, 'Humorous', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(345, 'Humorous', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(346, 'Hard-working', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(347, 'Hard-working', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(348, 'Enthusiastic', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(349, 'Enthusiastic', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(350, 'Diplomatic', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(351, 'Diplomatic', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(352, 'Creative', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(353, 'Creative', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(354, 'Convivial', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(355, 'Convivial', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(356, 'Conscientious', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(357, 'Conscientious', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(358, 'Communicative', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(359, 'Communicative', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(377, 'Brave', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(378, 'Brave', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(379, 'Ambitious', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(380, 'Ambitious', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(381, 'Sincere', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(382, 'Sincere', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(383, 'Sensible', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(384, 'Resourceful', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(385, 'Resourceful', 1, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
(386, 'Reliable', 0, 'PROVIDER', '2018-01-18 00:00:00', '2018-01-18 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productID` bigint(20) NOT NULL,
  `productUserID` bigint(20) NOT NULL,
  `productName` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `productPrice` int(11) NOT NULL,
  `productDescprition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `productAddedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage provider products';

-- --------------------------------------------------------

--
-- Table structure for table `products_images`
--

CREATE TABLE `products_images` (
  `productImageID` bigint(20) NOT NULL,
  `productParentID` bigint(20) NOT NULL,
  `productOriginalImage` text NOT NULL,
  `productThumbnailImage` text COMMENT '(200 * 200) '
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage product images';

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `reportID` bigint(20) NOT NULL,
  `reportUserID` bigint(20) DEFAULT NULL,
  `reportAmount` float(7,2) NOT NULL COMMENT '(In USD)',
  `reportAmountType` smallint(1) NOT NULL DEFAULT '1' COMMENT '0 = Deduct, 1 = Added',
  `reportModuleName` varchar(50) DEFAULT NULL,
  `reportExtraParams` text,
  `reportDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage all payment report & revenue';

-- --------------------------------------------------------

--
-- Table structure for table `report_flag_categories`
--

CREATE TABLE `report_flag_categories` (
  `reportFlagCategoryID` bigint(20) NOT NULL,
  `reportFlagCategoryName` varchar(150) NOT NULL,
  `reportFlagCategoryAddedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `report_flag_categories`
--

INSERT INTO `report_flag_categories` (`reportFlagCategoryID`, `reportFlagCategoryName`, `reportFlagCategoryAddedDate`) VALUES
(1, 'Fake', '2017-12-08 09:20:46'),
(2, 'Abusing', '2017-12-08 09:20:51');

-- --------------------------------------------------------

--
-- Table structure for table `report_users`
--

CREATE TABLE `report_users` (
  `userReportId` bigint(20) NOT NULL,
  `userReportUserId` bigint(20) NOT NULL,
  `userReportFriendId` bigint(20) NOT NULL,
  `userReportCategory` varchar(100) NOT NULL,
  `userReportDescprition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `userReportImage` text,
  `userReportImageThumbnail` text,
  `userReportVideo` text,
  `userReportVideoThumbnail` text,
  `userReportDateTime` datetime NOT NULL,
  `isAdminRemovedRedFlag` smallint(6) NOT NULL DEFAULT '0' COMMENT '0 = Default User Request, 1 = Yes',
  `adminRemoveReportFlagReason` text CHARACTER SET utf8,
  `adminRemoveReportFlagDateTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reschedule_calls`
--

CREATE TABLE `reschedule_calls` (
  `callReScheduleID` bigint(20) NOT NULL,
  `callScheduleID` bigint(20) NOT NULL,
  `callReScheduleDate` date NOT NULL,
  `callReScheduleTime` varchar(50) NOT NULL,
  `callReScheduleRequestDateTime` datetime NOT NULL,
  `callReScheduleRequestUserID` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reschedule_dating`
--

CREATE TABLE `reschedule_dating` (
  `datingReScheduleID` bigint(20) NOT NULL,
  `datingScheduleID` bigint(20) NOT NULL,
  `datingReScheduleDate` date NOT NULL,
  `datingReScheduleTime` varchar(50) NOT NULL,
  `datingReScheduleLocation` text NOT NULL,
  `datingReScheduleLocationLatitude` varchar(150) DEFAULT NULL,
  `datingReScheduleLongitude` varchar(150) DEFAULT NULL,
  `datingReScheduleAfterMath` varchar(150) NOT NULL,
  `datingReScheduleRequestDateTime` datetime NOT NULL,
  `datingReScheduleRequestUserID` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schedule_calls`
--

CREATE TABLE `schedule_calls` (
  `callScheduleID` bigint(20) NOT NULL,
  `callScheduleModuleName` enum('FRIENDLY','DATING','PROVIDER') NOT NULL,
  `callScheduleUserID` bigint(20) NOT NULL COMMENT '(Sender ID)',
  `callScheduleFriendID` bigint(20) NOT NULL COMMENT '(Receiver ID)',
  `callScheduleDate` date NOT NULL,
  `callScheduleTime` time NOT NULL,
  `callScheduleTimeZone` varchar(50) DEFAULT NULL,
  `callScheduleUserStatus` enum('PENDING','ACCEPT','REJECT','CANCELLED') DEFAULT 'PENDING',
  `callScheduleFriendStatus` enum('PENDING','ACCEPT','REJECT','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `callGlobalStatus` enum('PENDING','ACCEPT','REJECT','AUTO_REJECT','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `callNote` varchar(255) DEFAULT NULL,
  `callScheduleUserResponseDateTime` datetime DEFAULT NULL,
  `callScheduleFriendResponseDateTime` datetime DEFAULT NULL,
  `isScheduledCallMutuallyConfirmed` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `userCallRequestTime` datetime NOT NULL COMMENT '(For one to one, scheduled calls)',
  `isCallRescheduled` smallint(6) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `lastRescheduleCallRequestTime` datetime DEFAULT NULL,
  `isNotificationSent` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `isUserCallReviewDone` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `userCallReview` decimal(10,0) DEFAULT NULL COMMENT '(Review after call finish)'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user calls,scheduled calls, group calls';

-- --------------------------------------------------------

--
-- Table structure for table `schedule_dating`
--

CREATE TABLE `schedule_dating` (
  `datingScheduleID` bigint(20) NOT NULL,
  `datingScheduleModuleName` enum('FRIENDLY','DATING','PROVIDER') NOT NULL,
  `datingScheduleUserID` bigint(20) NOT NULL COMMENT '(Sender ID)',
  `datingScheduleFriendID` bigint(20) NOT NULL COMMENT '(Receiver ID)',
  `datingLocation` text NOT NULL,
  `datingLocationLatitude` varchar(150) DEFAULT NULL,
  `datingLocationLongitude` varchar(150) DEFAULT NULL,
  `datingAfterMath` varchar(150) NOT NULL,
  `datingScheduleDate` date NOT NULL,
  `datingScheduleTime` varchar(50) NOT NULL COMMENT '(24 Hours Format)',
  `datingScheduleTimeZone` varchar(50) DEFAULT NULL,
  `datingScheduleUserStatus` enum('PENDING','ACCEPT','REJECT','CANCELLED') DEFAULT 'PENDING',
  `datingScheduleFriendStatus` enum('PENDING','ACCEPT','REJECT','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `datingGlobalStatus` enum('PENDING','ACCEPT','REJECT','AUTO_REJECT','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `datesNote` varchar(255) DEFAULT NULL,
  `datingScheduleUserResponseDateTime` datetime DEFAULT NULL,
  `datingScheduleFriendResponseDateTime` datetime DEFAULT NULL,
  `isScheduledDateMutuallyConfirmed` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `userDateRequestTime` datetime NOT NULL COMMENT '(For one to one, scheduled dates)',
  `isDateRescheduled` smallint(6) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `lastRescheduleDateRequestTime` datetime DEFAULT NULL,
  `isUserDateReviewDone` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `userDateReview` decimal(10,0) DEFAULT NULL COMMENT '(Review after call finish)',
  `IsSenderDatingReviewDone` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `IsRecieverDatingReviewDone` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `senderDatingReview` smallint(1) DEFAULT NULL,
  `recieverDatingReview` smallint(1) DEFAULT NULL,
  `senderDatingReviewMessage` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recieverDatingReviewMessage` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senderDatingReviewDateTime` datetime DEFAULT NULL,
  `recieverDatingReviewDateTime` datetime DEFAULT NULL,
  `isNotificationSent` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `isScheduleNotificationSent` smallint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user dates,scheduled dates';

-- --------------------------------------------------------

--
-- Table structure for table `search_logs`
--

CREATE TABLE `search_logs` (
  `id` bigint(20) NOT NULL,
  `query` text NOT NULL,
  `totalResults` int(11) NOT NULL DEFAULT '0',
  `userId` bigint(20) NOT NULL,
  `datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `serviceID` bigint(20) NOT NULL,
  `serviceUserID` bigint(20) NOT NULL,
  `serviceName` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `serviceDescprition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `servicePrice` int(11) NOT NULL,
  `serviceType` enum('FIXED','HOURLY') NOT NULL,
  `serviceOriginalImage` text,
  `serviceThumbnailImage` text COMMENT '(250 * 250)',
  `serviceAddedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage provider services';

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `skillID` bigint(20) NOT NULL,
  `skillName` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `skillUserID` bigint(20) NOT NULL,
  `isMainSkill` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `skillAddedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage provider skills';

-- --------------------------------------------------------

--
-- Table structure for table `skill_preferences`
--

CREATE TABLE `skill_preferences` (
  `skillPreferenceId` bigint(20) NOT NULL,
  `skillPreferenceUserId` bigint(20) NOT NULL,
  `skillPreferenceType` enum('FRIENDLY','DATING','PROVIDER') NOT NULL DEFAULT 'PROVIDER',
  `skillPreferenceText` varchar(250) NOT NULL,
  `skillPreferenceCreatedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage provider skill preferences';

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transactionID` bigint(20) NOT NULL,
  `transactionUserID` bigint(20) NOT NULL,
  `transactionFriendID` bigint(20) DEFAULT NULL,
  `transactionCustomID` varchar(150) NOT NULL,
  `transactionAmount` float DEFAULT NULL,
  `transactionDateTime` datetime NOT NULL,
  `transactionStatus` enum('COMPLETED','FAILED','OTHER') NOT NULL,
  `transactionModuleName` varchar(100) DEFAULT NULL,
  `transactionMessage` varchar(250) DEFAULT NULL,
  `transactionPaymentID` text,
  `transactionMode` enum('ADVANCE','FROZEN','ADVANCE_AND_FROZEN','INSTANT') NOT NULL DEFAULT 'INSTANT',
  `transactionDisputed` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `transactionDisputeStatus` enum('NONE','PENDING','ADMIN_REJECTED','ADMIN_COMPLETED','USER_COMPLETED') NOT NULL DEFAULT 'NONE',
  `transactionPaymentResponse` text,
  `transactionParams` text,
  `transactionPaymentDateTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user transactions';

-- --------------------------------------------------------

--
-- Table structure for table `txn_disputes`
--

CREATE TABLE `txn_disputes` (
  `disputeID` bigint(20) NOT NULL,
  `disputeUserID` bigint(20) NOT NULL COMMENT '(Dispute Initiater)',
  `disputeTxnID` bigint(20) NOT NULL,
  `disputeReason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `disputeStatus` enum('PENDING','ADMIN_REJECTED','ADMIN_COMPLETED','USER_COMPLETED') NOT NULL DEFAULT 'PENDING',
  `disputeDateTime` datetime NOT NULL,
  `disputeResponseDateTime` datetime DEFAULT NULL,
  `disputeExtraParams` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage transaction disputes';

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `masterUserId` bigint(20) NOT NULL,
  `userEmail` varchar(250) NOT NULL,
  `userPassword` varchar(255) DEFAULT NULL,
  `userType` enum('NORMAL_USER','SUPER_ADMIN','BECOME_PROVIDER') NOT NULL DEFAULT 'NORMAL_USER'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='For user logins';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`masterUserId`, `userEmail`, `userPassword`, `userType`) VALUES
(149, 'admin@quicklove.com', 'e10adc3949ba59abbe56e057f20f883e', 'SUPER_ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `users_device_history`
--

CREATE TABLE `users_device_history` (
  `userDeviceHistoryId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `userDeviceToken` text NOT NULL COMMENT 'Used to send push notfications',
  `userDeviceType` enum('ANDROID','IOS') NOT NULL,
  `userDeviceId` varchar(150) NOT NULL COMMENT 'Device Unique ID',
  `deviceAddedDate` datetime NOT NULL,
  `deviceModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user devices history';

-- --------------------------------------------------------

--
-- Table structure for table `user_calls_reciever`
--

CREATE TABLE `user_calls_reciever` (
  `userCallsRecieverId` bigint(20) NOT NULL,
  `userCallsRecieverUserId` bigint(20) NOT NULL COMMENT '(Call Initiate User Id)',
  `userCallsRecieverFriendId` bigint(20) NOT NULL COMMENT '(Call Reciver User Id)',
  `userCallsRecieverCallId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user calls recevier users history';

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `userDetailsId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `userFirstName` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `userLastName` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `userAddress` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `userCountry` varchar(100) DEFAULT NULL,
  `userDOB` date DEFAULT NULL,
  `userLatitude` varchar(150) DEFAULT NULL,
  `userLongitude` varchar(150) DEFAULT NULL,
  `userSexualOrientation` varchar(150) DEFAULT NULL,
  `userMood` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userAge` int(10) UNSIGNED DEFAULT NULL,
  `userGender` enum('MALE','FEMALE','OTHER') DEFAULT NULL,
  `userCity` varchar(150) DEFAULT NULL,
  `userLoginSessionKey` varchar(255) DEFAULT NULL,
  `isSocialSignup` smallint(6) NOT NULL DEFAULT '0' COMMENT '0 = NO, 1 = YES',
  `userSocialType` enum('FACEBOOK','TWITTER','INSTAGRAM') DEFAULT NULL,
  `userSocialId` text,
  `userImage` text,
  `userImageThumbnail` text COMMENT '150*150',
  `userCoverImage` text,
  `userCoverImageThumbnail` text COMMENT '(400*200)',
  `isFacebookVerified` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `isTwitterVerified` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `isInstagramVerified` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `noOfVerifiedSocialAccounts` smallint(1) NOT NULL DEFAULT '0',
  `noOfRedFlags` smallint(6) NOT NULL DEFAULT '0',
  `isGroupChatEnable` smallint(1) NOT NULL DEFAULT '1' COMMENT '0 = No, 1 = Yes',
  `isOpenForAllCalls` smallint(1) NOT NULL DEFAULT '1' COMMENT '0 = No, 1 = Yes',
  `isOpenForScheduledCalls` smallint(1) NOT NULL DEFAULT '1' COMMENT '0 = No, 1 = Yes',
  `isHideProfileAsProvider` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `userMembershipStatus` smallint(2) NOT NULL DEFAULT '1' COMMENT '0 = Inactive, 1 = Active',
  `userProfileUpdateStatus` smallint(2) NOT NULL DEFAULT '0' COMMENT '0 = Not Updated, 1 = Updated',
  `userProfileImageStatus` smallint(2) NOT NULL DEFAULT '0' COMMENT '0 = Not Uploaded, 1 = Uploaded',
  `userCoverImageStatus` smallint(2) NOT NULL DEFAULT '0' COMMENT '0 = Not Uploaded, 1 = Uploaded',
  `userWholeProfileStatus` smallint(2) NOT NULL DEFAULT '0' COMMENT '0 = Incomplete, 1 = Completed (Including update profile, profile image, cover image)',
  `userMaxImageUploadStatus` smallint(2) NOT NULL DEFAULT '0' COMMENT '0 = 3 Images, 1 = 10 Images',
  `noOfAllowedImages` int(11) NOT NULL DEFAULT '10' COMMENT '( Default - 10)',
  `isDatingImagesCountAdded` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes (User can upload 5 more images after completing 5 dates)',
  `isJobsImagesCountAdded` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes (User can upload 5 more images after completing 5 jobs)',
  `userJobHeading` varchar(150) DEFAULT NULL,
  `userBadges` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `userWalletAmount` float NOT NULL DEFAULT '0',
  `userWalletHoldAmount` bigint(20) NOT NULL DEFAULT '0',
  `isPreferencesAdded` smallint(2) NOT NULL DEFAULT '0' COMMENT '0 = no, 1 = yes (FOR FRIENDS MODULES)',
  `isDatingPreferenceAdded` smallint(1) NOT NULL DEFAULT '0',
  `isProviderPreferenceAdded` smallint(1) NOT NULL DEFAULT '0',
  `userEmailVerified` smallint(6) NOT NULL DEFAULT '0' COMMENT '0 = no, 1 = yes',
  `userPaymentAccountID` varchar(150) DEFAULT NULL COMMENT '(Stripe Account ID)',
  `userPaymentCustomerID` varchar(150) DEFAULT NULL COMMENT '(Stripe Customer ID)',
  `userInterestedGender` varchar(50) DEFAULT NULL,
  `userInterestedSexualOrientation` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userRating` float NOT NULL DEFAULT '0',
  `noOfReviews` int(11) NOT NULL DEFAULT '0',
  `isBecomeProvider` smallint(1) NOT NULL DEFAULT '0',
  `isUserBlocked` smallint(6) NOT NULL DEFAULT '0' COMMENT '0 = no, 1 = yes (By Admin)',
  `isUserDeactivated` smallint(6) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes (By User)',
  `userTempCode` varchar(50) DEFAULT NULL,
  `userTempCodeSentTime` datetime DEFAULT NULL,
  `isRedFlagBlock` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes',
  `onlineStatus` enum('ONLINE','OFFLINE','AWAY','NONE') NOT NULL DEFAULT 'ONLINE',
  `redFlagBlockDateTime` datetime DEFAULT NULL COMMENT '(By Admin)',
  `isPaidMembeship` smallint(1) NOT NULL DEFAULT '0' COMMENT '0 = No, 1 = Yes ($19 app membership one time only)',
  `paidMemebershipDate` datetime DEFAULT NULL,
  `userRegistrationDate` datetime NOT NULL,
  `userNextThreeMonthDateTime` datetime DEFAULT NULL,
  `userTimeZone` varchar(50) CHARACTER SET utf8 DEFAULT 'America/Los_Angeles',
  `userLastLogin` datetime DEFAULT NULL,
  `userLastIpAddress` varchar(150) DEFAULT NULL,
  `userLastActivityDateTime` datetime DEFAULT NULL,
  `isUserLoggedOut` smallint(1) NOT NULL DEFAULT '1' COMMENT '0 = No, 1 = Yes'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user details';

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`userDetailsId`, `userId`, `userFirstName`, `userLastName`, `userAddress`, `userCountry`, `userDOB`, `userLatitude`, `userLongitude`, `userSexualOrientation`, `userMood`, `userAge`, `userGender`, `userCity`, `userLoginSessionKey`, `isSocialSignup`, `userSocialType`, `userSocialId`, `userImage`, `userImageThumbnail`, `userCoverImage`, `userCoverImageThumbnail`, `isFacebookVerified`, `isTwitterVerified`, `isInstagramVerified`, `noOfVerifiedSocialAccounts`, `noOfRedFlags`, `isGroupChatEnable`, `isOpenForAllCalls`, `isOpenForScheduledCalls`, `isHideProfileAsProvider`, `userMembershipStatus`, `userProfileUpdateStatus`, `userProfileImageStatus`, `userCoverImageStatus`, `userWholeProfileStatus`, `userMaxImageUploadStatus`, `noOfAllowedImages`, `isDatingImagesCountAdded`, `isJobsImagesCountAdded`, `userJobHeading`, `userBadges`, `userWalletAmount`, `userWalletHoldAmount`, `isPreferencesAdded`, `isDatingPreferenceAdded`, `isProviderPreferenceAdded`, `userEmailVerified`, `userPaymentAccountID`, `userPaymentCustomerID`, `userInterestedGender`, `userInterestedSexualOrientation`, `userRating`, `noOfReviews`, `isBecomeProvider`, `isUserBlocked`, `isUserDeactivated`, `userTempCode`, `userTempCodeSentTime`, `isRedFlagBlock`, `onlineStatus`, `redFlagBlockDateTime`, `isPaidMembeship`, `paidMemebershipDate`, `userRegistrationDate`, `userNextThreeMonthDateTime`, `userTimeZone`, `userLastLogin`, `userLastIpAddress`, `userLastActivityDateTime`, `isUserLoggedOut`) VALUES
(46, 149, 'Quick', 'love', NULL, 'India', NULL, NULL, NULL, NULL, NULL, NULL, 'MALE', NULL, '1496c77832c-b1b0-55a8-ea9f-842896337ff2', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 10, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 1, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, NULL, NULL, 0, 'ONLINE', NULL, 0, NULL, '2017-11-05 07:24:24', NULL, 'America/Los_Angeles', '2018-03-14 12:05:35', '172.31.41.4', '2018-03-15 09:41:53', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_gallery_images`
--

CREATE TABLE `user_gallery_images` (
  `userGalleryImageId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `userOriginalImage` text NOT NULL,
  `userThumbnailImage` text NOT NULL COMMENT '(250 * 250)',
  `userGalleryImageCreatedDate` datetime NOT NULL,
  `userGalleryImageModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user gallery images';

-- --------------------------------------------------------

--
-- Table structure for table `user_inbox`
--

CREATE TABLE `user_inbox` (
  `userInboxId` bigint(20) NOT NULL,
  `userInboxSenderId` bigint(20) NOT NULL,
  `userInboxRecieverId` bigint(20) NOT NULL,
  `userInboxType` varchar(150) DEFAULT NULL,
  `userInboxMessage` text NOT NULL,
  `userInboxSentTime` datetime NOT NULL,
  `userInboxExtraParams` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user inbox messages';

-- --------------------------------------------------------

--
-- Table structure for table `user_preferences`
--

CREATE TABLE `user_preferences` (
  `userPreferenceId` bigint(20) NOT NULL,
  `userPreferenceUserId` bigint(20) NOT NULL,
  `userPreferenceType` enum('FRIENDLY','DATING','PROVIDER') NOT NULL,
  `userPreferenceFieldType` enum('BEST_THINGS_DESCRIBE_YOU','THINGS_LOOKING_IN_FRIEND','DEAL_BREAKERS') NOT NULL,
  `userPreferenceText` varchar(250) NOT NULL,
  `userPreferenceCreatedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user preferences for Friendly, Dating, Provider';

-- --------------------------------------------------------

--
-- Table structure for table `user_social_verifications`
--

CREATE TABLE `user_social_verifications` (
  `userSocialVerificationID` bigint(20) NOT NULL,
  `userID` bigint(20) NOT NULL,
  `userSocialID` varchar(250) NOT NULL,
  `userSocialEmailId` varchar(250) NOT NULL,
  `userSocialType` enum('FACEBOOK','TWITTER','INSTAGRAM') NOT NULL,
  `IsVerified` smallint(2) NOT NULL DEFAULT '0',
  `verificationMode` enum('BY_SOCIAL_SIGNUP','BY_VERIFICATION') NOT NULL DEFAULT 'BY_SOCIAL_SIGNUP',
  `userSocialTempCode` int(11) DEFAULT NULL,
  `userSocialTempCodeSentTime` datetime DEFAULT NULL,
  `userVerificationDateTime` datetime NOT NULL COMMENT '(In UTC)'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user social verification accounts';

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `videoID` bigint(20) NOT NULL,
  `videoUserID` bigint(11) NOT NULL,
  `videoLength` int(11) DEFAULT NULL COMMENT '(In Seconds)',
  `videoSize` bigint(20) DEFAULT NULL COMMENT '(In Bytes)',
  `videoPath` text NOT NULL,
  `videoThumbnailPath` text,
  `videoAddedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user videos';

-- --------------------------------------------------------

--
-- Table structure for table `wallet`
--

CREATE TABLE `wallet` (
  `walletID` bigint(20) NOT NULL,
  `walletUserID` bigint(20) NOT NULL,
  `walletAmount` int(11) NOT NULL,
  `walletRemainingAmount` float(7,2) DEFAULT NULL COMMENT '(After current trxn)',
  `walletTxnType` enum('ADDED','DEDUCT','NONE') NOT NULL DEFAULT 'NONE' COMMENT '(Money transfer from main account)',
  `walletTxnReason` varchar(150) DEFAULT NULL,
  `walletTxnID` varchar(150) DEFAULT NULL,
  `walletTxnStatus` enum('PENDING','FAILED','COMPLETED') NOT NULL DEFAULT 'PENDING',
  `walletTxnDateTime` datetime NOT NULL,
  `walletExtraParams` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='To manage user wallet';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  ADD PRIMARY KEY (`adminNotificationID`);

--
-- Indexes for table `allowed_images_history`
--
ALTER TABLE `allowed_images_history`
  ADD PRIMARY KEY (`allowedImageID`),
  ADD KEY `allowedImageUserID` (`allowedImageUserID`);

--
-- Indexes for table `block_users`
--
ALTER TABLE `block_users`
  ADD PRIMARY KEY (`userBlockId`),
  ADD KEY `userBlockUserId` (`userBlockUserId`),
  ADD KEY `userBlockFriendId` (`userBlockFriendId`);

--
-- Indexes for table `call_history`
--
ALTER TABLE `call_history`
  ADD PRIMARY KEY (`callHistoryID`),
  ADD KEY `callHistorySenderUserID` (`callSenderUserID`),
  ADD KEY `callHistoryRecieverUserID` (`callRecieverUserID`);

--
-- Indexes for table `call_history_users`
--
ALTER TABLE `call_history_users`
  ADD PRIMARY KEY (`callHistoryUsersID`),
  ADD KEY `callHistoryID` (`callHistoryID`),
  ADD KEY `callUserID` (`callUserID`);

--
-- Indexes for table `call_review`
--
ALTER TABLE `call_review`
  ADD PRIMARY KEY (`callReviewID`),
  ADD KEY `callReviewUserID` (`callReviewUserID`),
  ADD KEY `callReviewCallHistoryID` (`callReviewCallHistoryID`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`contactId`),
  ADD KEY `contactUserId` (`contactUserId`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`contentId`),
  ADD UNIQUE KEY `contentType` (`contentType`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`countryId`);

--
-- Indexes for table `dating_review`
--
ALTER TABLE `dating_review`
  ADD PRIMARY KEY (`datingReviewID`),
  ADD KEY `datingReviewUserID` (`datingReviewUserID`),
  ADD KEY `datingReviewCallHistoryID` (`datingReviewDateScheduleID`),
  ADD KEY `datingReviewUserID_2` (`datingReviewUserID`),
  ADD KEY `datingReviewCallHistoryID_2` (`datingReviewDateScheduleID`);

--
-- Indexes for table `deal_breaker_preferences`
--
ALTER TABLE `deal_breaker_preferences`
  ADD PRIMARY KEY (`dealBreakerPreferenceId`),
  ADD KEY `dealBreakerPreferenceUserId` (`dealBreakerPreferenceUserId`);

--
-- Indexes for table `describe_preferences`
--
ALTER TABLE `describe_preferences`
  ADD PRIMARY KEY (`describePreferenceId`),
  ADD KEY `userPreferenceUserId` (`describePreferenceUserId`),
  ADD KEY `friendPreferenceParentID` (`describePreferenceParentID`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`masterFriendId`),
  ADD KEY `userId` (`userId`),
  ADD KEY `friendId` (`friendId`);

--
-- Indexes for table `hold_amounts`
--
ALTER TABLE `hold_amounts`
  ADD PRIMARY KEY (`holdAmountID`),
  ADD UNIQUE KEY `holdAmountJobID_2` (`holdAmountJobID`),
  ADD KEY `holdAmountUserID` (`holdAmountUserID`),
  ADD KEY `holdAmountJobID` (`holdAmountJobID`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`jobID`),
  ADD KEY `jobHirerUserID` (`jobHirerUserID`),
  ADD KEY `jobProviderUserID` (`jobProviderUserID`);

--
-- Indexes for table `jobs_payment_distribution`
--
ALTER TABLE `jobs_payment_distribution`
  ADD PRIMARY KEY (`jobPaymentDistributionID`),
  ADD UNIQUE KEY `jobParentID_3` (`jobParentID`),
  ADD KEY `jobParentID` (`jobParentID`),
  ADD KEY `jobParentID_2` (`jobParentID`);

--
-- Indexes for table `jobs_review`
--
ALTER TABLE `jobs_review`
  ADD PRIMARY KEY (`jobReviewID`),
  ADD KEY `jobReviewUserID` (`jobReviewUserID`),
  ADD KEY `jobReviewParentID` (`jobReviewParentID`);

--
-- Indexes for table `job_cancel`
--
ALTER TABLE `job_cancel`
  ADD PRIMARY KEY (`jobCancelID`),
  ADD KEY `jobCancelUserID` (`jobCancelUserID`),
  ADD KEY `jobParentID` (`jobParentID`);

--
-- Indexes for table `job_disputes`
--
ALTER TABLE `job_disputes`
  ADD PRIMARY KEY (`jobDisputeID`),
  ADD KEY `jobDisputeUserID` (`jobDisputeUserID`),
  ADD KEY `jobParentID` (`jobParentID`);

--
-- Indexes for table `looking_preferences`
--
ALTER TABLE `looking_preferences`
  ADD PRIMARY KEY (`lookingPreferenceId`),
  ADD KEY `userPreferenceUserId` (`lookingPreferenceUserId`),
  ADD KEY `looking_preferences_ibfk_2` (`lookingPreferenceParentID`);

--
-- Indexes for table `milestones`
--
ALTER TABLE `milestones`
  ADD PRIMARY KEY (`milestoneID`),
  ADD KEY `milestoneJobID` (`milestoneJobID`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notificationId`),
  ADD KEY `user_id` (`notificationUserId`),
  ADD KEY `sender_id` (`notificationFriendId`),
  ADD KEY `friendModuleId` (`friendModuleId`),
  ADD KEY `callScheduleModuleID` (`callScheduleModuleID`),
  ADD KEY `dateScheduleModuleID` (`dateScheduleModuleID`),
  ADD KEY `jobModuleID` (`jobModuleID`),
  ADD KEY `jobModuleID_2` (`jobModuleID`),
  ADD KEY `orderModuleID` (`orderModuleID`),
  ADD KEY `reportModuleID` (`reportModuleID`),
  ADD KEY `callHistoryModuleID` (`callHistoryModuleID`),
  ADD KEY `txnModuleID` (`txnModuleID`),
  ADD KEY `contactModuleId` (`contactModuleId`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `orderUserID` (`orderUserID`),
  ADD KEY `orderProductOwnerUserID` (`orderProductOwnerUserID`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`orderProductID`),
  ADD KEY `orderProductUserID` (`orderProductUserID`),
  ADD KEY `orderParentID` (`orderParentID`);

--
-- Indexes for table `preferences`
--
ALTER TABLE `preferences`
  ADD PRIMARY KEY (`preferenceID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productID`),
  ADD KEY `productUserID` (`productUserID`);

--
-- Indexes for table `products_images`
--
ALTER TABLE `products_images`
  ADD PRIMARY KEY (`productImageID`),
  ADD KEY `productParentID` (`productParentID`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`reportID`);

--
-- Indexes for table `report_flag_categories`
--
ALTER TABLE `report_flag_categories`
  ADD PRIMARY KEY (`reportFlagCategoryID`),
  ADD UNIQUE KEY `reportFlagCategoryName` (`reportFlagCategoryName`);

--
-- Indexes for table `report_users`
--
ALTER TABLE `report_users`
  ADD PRIMARY KEY (`userReportId`),
  ADD KEY `userReportUserId` (`userReportUserId`),
  ADD KEY `userReportFriendId` (`userReportFriendId`);

--
-- Indexes for table `reschedule_calls`
--
ALTER TABLE `reschedule_calls`
  ADD PRIMARY KEY (`callReScheduleID`),
  ADD KEY `callScheduleID` (`callScheduleID`),
  ADD KEY `callReScheduleRequestUserID` (`callReScheduleRequestUserID`),
  ADD KEY `callScheduleID_2` (`callScheduleID`),
  ADD KEY `callReScheduleRequestUserID_2` (`callReScheduleRequestUserID`);

--
-- Indexes for table `reschedule_dating`
--
ALTER TABLE `reschedule_dating`
  ADD PRIMARY KEY (`datingReScheduleID`),
  ADD KEY `datingScheduleID` (`datingScheduleID`),
  ADD KEY `datingScheduleID_2` (`datingScheduleID`),
  ADD KEY `datingReScheduleRequestDateTime` (`datingReScheduleRequestDateTime`),
  ADD KEY `datingReScheduleRequestUserID` (`datingReScheduleRequestUserID`);

--
-- Indexes for table `schedule_calls`
--
ALTER TABLE `schedule_calls`
  ADD PRIMARY KEY (`callScheduleID`),
  ADD KEY `userCallIntitateUserId` (`callScheduleUserID`),
  ADD KEY `callScheduleOpponentUserID` (`callScheduleFriendID`),
  ADD KEY `callScheduleUserID` (`callScheduleUserID`),
  ADD KEY `callScheduleFriendID` (`callScheduleFriendID`);

--
-- Indexes for table `schedule_dating`
--
ALTER TABLE `schedule_dating`
  ADD PRIMARY KEY (`datingScheduleID`),
  ADD KEY `datingScheduleUserID` (`datingScheduleUserID`),
  ADD KEY `datingScheduleFriendID` (`datingScheduleFriendID`),
  ADD KEY `datingScheduleID` (`datingScheduleID`);

--
-- Indexes for table `search_logs`
--
ALTER TABLE `search_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`serviceID`),
  ADD KEY `serviceUserID` (`serviceUserID`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`skillID`),
  ADD KEY `skillUserID` (`skillUserID`);

--
-- Indexes for table `skill_preferences`
--
ALTER TABLE `skill_preferences`
  ADD PRIMARY KEY (`skillPreferenceId`),
  ADD KEY `skillPreferenceUserId` (`skillPreferenceUserId`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transactionID`),
  ADD KEY `transactionUserID` (`transactionUserID`),
  ADD KEY `transactionFriendID` (`transactionFriendID`);

--
-- Indexes for table `txn_disputes`
--
ALTER TABLE `txn_disputes`
  ADD PRIMARY KEY (`disputeID`),
  ADD UNIQUE KEY `disputeTxnID_2` (`disputeTxnID`),
  ADD KEY `disputeUserID` (`disputeUserID`),
  ADD KEY `disputeTxnID` (`disputeTxnID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`masterUserId`),
  ADD UNIQUE KEY `email` (`userEmail`),
  ADD KEY `id` (`masterUserId`);

--
-- Indexes for table `users_device_history`
--
ALTER TABLE `users_device_history`
  ADD PRIMARY KEY (`userDeviceHistoryId`),
  ADD UNIQUE KEY `device_id` (`userDeviceId`),
  ADD KEY `user_id` (`userId`),
  ADD KEY `user_id_2` (`userId`),
  ADD KEY `user_id_3` (`userId`),
  ADD KEY `user_id_4` (`userId`),
  ADD KEY `user_id_5` (`userId`),
  ADD KEY `user_id_6` (`userId`);

--
-- Indexes for table `user_calls_reciever`
--
ALTER TABLE `user_calls_reciever`
  ADD PRIMARY KEY (`userCallsRecieverId`),
  ADD KEY `userCallsRecieverUserId` (`userCallsRecieverUserId`),
  ADD KEY `userCallsRecieverFriendId` (`userCallsRecieverFriendId`),
  ADD KEY `userCallsRecieverCallId` (`userCallsRecieverCallId`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`userDetailsId`),
  ADD UNIQUE KEY `userId_2` (`userId`),
  ADD UNIQUE KEY `userLoginSessionKey` (`userLoginSessionKey`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `user_gallery_images`
--
ALTER TABLE `user_gallery_images`
  ADD PRIMARY KEY (`userGalleryImageId`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `user_inbox`
--
ALTER TABLE `user_inbox`
  ADD PRIMARY KEY (`userInboxId`),
  ADD KEY `userInboxSenderId` (`userInboxSenderId`),
  ADD KEY `userInboxRecieverId` (`userInboxRecieverId`),
  ADD KEY `userInboxSenderId_2` (`userInboxSenderId`),
  ADD KEY `userInboxRecieverId_2` (`userInboxRecieverId`);

--
-- Indexes for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD PRIMARY KEY (`userPreferenceId`),
  ADD KEY `userPreferenceUserId` (`userPreferenceUserId`);

--
-- Indexes for table `user_social_verifications`
--
ALTER TABLE `user_social_verifications`
  ADD PRIMARY KEY (`userSocialVerificationID`),
  ADD UNIQUE KEY `userSocialID` (`userSocialID`),
  ADD UNIQUE KEY `userSocialEmailId` (`userSocialEmailId`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`videoID`),
  ADD KEY `videoUserID` (`videoUserID`);

--
-- Indexes for table `wallet`
--
ALTER TABLE `wallet`
  ADD PRIMARY KEY (`walletID`),
  ADD KEY `walletUserID` (`walletUserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  MODIFY `adminNotificationID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `allowed_images_history`
--
ALTER TABLE `allowed_images_history`
  MODIFY `allowedImageID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `block_users`
--
ALTER TABLE `block_users`
  MODIFY `userBlockId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `call_history`
--
ALTER TABLE `call_history`
  MODIFY `callHistoryID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=678;
--
-- AUTO_INCREMENT for table `call_history_users`
--
ALTER TABLE `call_history_users`
  MODIFY `callHistoryUsersID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `call_review`
--
ALTER TABLE `call_review`
  MODIFY `callReviewID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `contactId` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `contentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `countryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;
--
-- AUTO_INCREMENT for table `dating_review`
--
ALTER TABLE `dating_review`
  MODIFY `datingReviewID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `deal_breaker_preferences`
--
ALTER TABLE `deal_breaker_preferences`
  MODIFY `dealBreakerPreferenceId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `describe_preferences`
--
ALTER TABLE `describe_preferences`
  MODIFY `describePreferenceId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `masterFriendId` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=396;
--
-- AUTO_INCREMENT for table `hold_amounts`
--
ALTER TABLE `hold_amounts`
  MODIFY `holdAmountID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `jobID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=186;
--
-- AUTO_INCREMENT for table `jobs_payment_distribution`
--
ALTER TABLE `jobs_payment_distribution`
  MODIFY `jobPaymentDistributionID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `jobs_review`
--
ALTER TABLE `jobs_review`
  MODIFY `jobReviewID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `job_cancel`
--
ALTER TABLE `job_cancel`
  MODIFY `jobCancelID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `job_disputes`
--
ALTER TABLE `job_disputes`
  MODIFY `jobDisputeID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `looking_preferences`
--
ALTER TABLE `looking_preferences`
  MODIFY `lookingPreferenceId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `milestones`
--
ALTER TABLE `milestones`
  MODIFY `milestoneID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notificationId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;
--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `orderProductID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `preferences`
--
ALTER TABLE `preferences`
  MODIFY `preferenceID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=387;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `products_images`
--
ALTER TABLE `products_images`
  MODIFY `productImageID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `reportID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `report_flag_categories`
--
ALTER TABLE `report_flag_categories`
  MODIFY `reportFlagCategoryID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `report_users`
--
ALTER TABLE `report_users`
  MODIFY `userReportId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reschedule_calls`
--
ALTER TABLE `reschedule_calls`
  MODIFY `callReScheduleID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reschedule_dating`
--
ALTER TABLE `reschedule_dating`
  MODIFY `datingReScheduleID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `schedule_calls`
--
ALTER TABLE `schedule_calls`
  MODIFY `callScheduleID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=259;
--
-- AUTO_INCREMENT for table `schedule_dating`
--
ALTER TABLE `schedule_dating`
  MODIFY `datingScheduleID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `search_logs`
--
ALTER TABLE `search_logs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `serviceID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `skillID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `skill_preferences`
--
ALTER TABLE `skill_preferences`
  MODIFY `skillPreferenceId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transactionID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;
--
-- AUTO_INCREMENT for table `txn_disputes`
--
ALTER TABLE `txn_disputes`
  MODIFY `disputeID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `masterUserId` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;
--
-- AUTO_INCREMENT for table `users_device_history`
--
ALTER TABLE `users_device_history`
  MODIFY `userDeviceHistoryId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_calls_reciever`
--
ALTER TABLE `user_calls_reciever`
  MODIFY `userCallsRecieverId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `userDetailsId` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;
--
-- AUTO_INCREMENT for table `user_gallery_images`
--
ALTER TABLE `user_gallery_images`
  MODIFY `userGalleryImageId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_inbox`
--
ALTER TABLE `user_inbox`
  MODIFY `userInboxId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_preferences`
--
ALTER TABLE `user_preferences`
  MODIFY `userPreferenceId` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_social_verifications`
--
ALTER TABLE `user_social_verifications`
  MODIFY `userSocialVerificationID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `videoID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wallet`
--
ALTER TABLE `wallet`
  MODIFY `walletID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `allowed_images_history`
--
ALTER TABLE `allowed_images_history`
  ADD CONSTRAINT `allowed_images_history_ibfk_1` FOREIGN KEY (`allowedImageUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `block_users`
--
ALTER TABLE `block_users`
  ADD CONSTRAINT `block_users_ibfk_1` FOREIGN KEY (`userBlockUserId`) REFERENCES `users` (`masterUserId`),
  ADD CONSTRAINT `block_users_ibfk_2` FOREIGN KEY (`userBlockFriendId`) REFERENCES `users` (`masterUserId`);

--
-- Constraints for table `call_history`
--
ALTER TABLE `call_history`
  ADD CONSTRAINT `call_history_ibfk_1` FOREIGN KEY (`callSenderUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `call_history_ibfk_2` FOREIGN KEY (`callRecieverUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `call_history_users`
--
ALTER TABLE `call_history_users`
  ADD CONSTRAINT `call_history_users_ibfk_1` FOREIGN KEY (`callHistoryID`) REFERENCES `call_history` (`callHistoryID`) ON DELETE CASCADE,
  ADD CONSTRAINT `call_history_users_ibfk_2` FOREIGN KEY (`callUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `call_review`
--
ALTER TABLE `call_review`
  ADD CONSTRAINT `call_review_ibfk_1` FOREIGN KEY (`callReviewUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `call_review_ibfk_2` FOREIGN KEY (`callReviewCallHistoryID`) REFERENCES `call_history` (`callHistoryID`) ON DELETE CASCADE;

--
-- Constraints for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD CONSTRAINT `contact_us_ibfk_1` FOREIGN KEY (`contactUserId`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `dating_review`
--
ALTER TABLE `dating_review`
  ADD CONSTRAINT `dating_review_ibfk_1` FOREIGN KEY (`datingReviewUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `dating_review_ibfk_2` FOREIGN KEY (`datingReviewDateScheduleID`) REFERENCES `schedule_dating` (`datingScheduleID`) ON DELETE CASCADE;

--
-- Constraints for table `deal_breaker_preferences`
--
ALTER TABLE `deal_breaker_preferences`
  ADD CONSTRAINT `deal_breaker_preferences_ibfk_1` FOREIGN KEY (`dealBreakerPreferenceUserId`) REFERENCES `users` (`masterUserId`);

--
-- Constraints for table `describe_preferences`
--
ALTER TABLE `describe_preferences`
  ADD CONSTRAINT `describe_preferences_ibfk_1` FOREIGN KEY (`describePreferenceUserId`) REFERENCES `users` (`masterUserId`),
  ADD CONSTRAINT `describe_preferences_ibfk_2` FOREIGN KEY (`describePreferenceParentID`) REFERENCES `preferences` (`preferenceID`) ON DELETE CASCADE;

--
-- Constraints for table `friends`
--
ALTER TABLE `friends`
  ADD CONSTRAINT `friends_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`masterUserId`),
  ADD CONSTRAINT `friends_ibfk_2` FOREIGN KEY (`friendId`) REFERENCES `users` (`masterUserId`);

--
-- Constraints for table `hold_amounts`
--
ALTER TABLE `hold_amounts`
  ADD CONSTRAINT `hold_amounts_ibfk_1` FOREIGN KEY (`holdAmountUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `hold_amounts_ibfk_2` FOREIGN KEY (`holdAmountJobID`) REFERENCES `jobs` (`jobID`) ON DELETE CASCADE;

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`jobHirerUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `jobs_ibfk_2` FOREIGN KEY (`jobProviderUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `jobs_payment_distribution`
--
ALTER TABLE `jobs_payment_distribution`
  ADD CONSTRAINT `jobs_payment_distribution_ibfk_1` FOREIGN KEY (`jobParentID`) REFERENCES `jobs` (`jobID`) ON DELETE CASCADE;

--
-- Constraints for table `jobs_review`
--
ALTER TABLE `jobs_review`
  ADD CONSTRAINT `jobs_review_ibfk_1` FOREIGN KEY (`jobReviewUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `jobs_review_ibfk_2` FOREIGN KEY (`jobReviewParentID`) REFERENCES `jobs` (`jobID`) ON DELETE CASCADE;

--
-- Constraints for table `job_cancel`
--
ALTER TABLE `job_cancel`
  ADD CONSTRAINT `job_cancel_ibfk_1` FOREIGN KEY (`jobCancelUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `job_cancel_ibfk_2` FOREIGN KEY (`jobParentID`) REFERENCES `jobs` (`jobID`) ON DELETE CASCADE;

--
-- Constraints for table `job_disputes`
--
ALTER TABLE `job_disputes`
  ADD CONSTRAINT `job_disputes_ibfk_1` FOREIGN KEY (`jobDisputeUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `job_disputes_ibfk_3` FOREIGN KEY (`jobParentID`) REFERENCES `jobs` (`jobID`) ON DELETE CASCADE;

--
-- Constraints for table `looking_preferences`
--
ALTER TABLE `looking_preferences`
  ADD CONSTRAINT `looking_preferences_ibfk_1` FOREIGN KEY (`lookingPreferenceUserId`) REFERENCES `users` (`masterUserId`),
  ADD CONSTRAINT `looking_preferences_ibfk_2` FOREIGN KEY (`lookingPreferenceParentID`) REFERENCES `preferences` (`preferenceID`) ON DELETE CASCADE;

--
-- Constraints for table `milestones`
--
ALTER TABLE `milestones`
  ADD CONSTRAINT `milestones_ibfk_1` FOREIGN KEY (`milestoneJobID`) REFERENCES `jobs` (`jobID`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`notificationUserId`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_10` FOREIGN KEY (`callHistoryModuleID`) REFERENCES `call_history` (`callHistoryID`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_11` FOREIGN KEY (`txnModuleID`) REFERENCES `transactions` (`transactionID`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_12` FOREIGN KEY (`contactModuleId`) REFERENCES `contact_us` (`contactId`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`notificationFriendId`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_3` FOREIGN KEY (`friendModuleId`) REFERENCES `friends` (`masterFriendId`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_4` FOREIGN KEY (`callScheduleModuleID`) REFERENCES `schedule_calls` (`callScheduleID`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_6` FOREIGN KEY (`dateScheduleModuleID`) REFERENCES `schedule_dating` (`datingScheduleID`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_7` FOREIGN KEY (`jobModuleID`) REFERENCES `jobs` (`jobID`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_8` FOREIGN KEY (`orderModuleID`) REFERENCES `orders` (`orderID`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_9` FOREIGN KEY (`reportModuleID`) REFERENCES `report_users` (`userReportId`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`orderUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`orderProductOwnerUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products_ibfk_1` FOREIGN KEY (`orderProductUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_products_ibfk_2` FOREIGN KEY (`orderParentID`) REFERENCES `orders` (`orderID`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`productUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `products_images`
--
ALTER TABLE `products_images`
  ADD CONSTRAINT `products_images_ibfk_1` FOREIGN KEY (`productParentID`) REFERENCES `products` (`productID`) ON DELETE CASCADE;

--
-- Constraints for table `report_users`
--
ALTER TABLE `report_users`
  ADD CONSTRAINT `report_users_ibfk_1` FOREIGN KEY (`userReportUserId`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `report_users_ibfk_2` FOREIGN KEY (`userReportFriendId`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `reschedule_calls`
--
ALTER TABLE `reschedule_calls`
  ADD CONSTRAINT `reschedule_calls_ibfk_1` FOREIGN KEY (`callScheduleID`) REFERENCES `schedule_calls` (`callScheduleID`) ON DELETE CASCADE,
  ADD CONSTRAINT `reschedule_calls_ibfk_2` FOREIGN KEY (`callReScheduleRequestUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `reschedule_dating`
--
ALTER TABLE `reschedule_dating`
  ADD CONSTRAINT `reschedule_dating_ibfk_1` FOREIGN KEY (`datingScheduleID`) REFERENCES `schedule_dating` (`datingScheduleID`) ON DELETE CASCADE,
  ADD CONSTRAINT `reschedule_dating_ibfk_2` FOREIGN KEY (`datingReScheduleRequestUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `schedule_calls`
--
ALTER TABLE `schedule_calls`
  ADD CONSTRAINT `schedule_calls_ibfk_1` FOREIGN KEY (`callScheduleUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `schedule_calls_ibfk_2` FOREIGN KEY (`callScheduleFriendID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `schedule_dating`
--
ALTER TABLE `schedule_dating`
  ADD CONSTRAINT `schedule_dating_ibfk_1` FOREIGN KEY (`datingScheduleUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `schedule_dating_ibfk_2` FOREIGN KEY (`datingScheduleFriendID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_ibfk_1` FOREIGN KEY (`serviceUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `skills`
--
ALTER TABLE `skills`
  ADD CONSTRAINT `skills_ibfk_1` FOREIGN KEY (`skillUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `skill_preferences`
--
ALTER TABLE `skill_preferences`
  ADD CONSTRAINT `skill_preferences_ibfk_1` FOREIGN KEY (`skillPreferenceUserId`) REFERENCES `users` (`masterUserId`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`transactionUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`transactionFriendID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

--
-- Constraints for table `txn_disputes`
--
ALTER TABLE `txn_disputes`
  ADD CONSTRAINT `txn_disputes_ibfk_1` FOREIGN KEY (`disputeUserID`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE,
  ADD CONSTRAINT `txn_disputes_ibfk_3` FOREIGN KEY (`disputeTxnID`) REFERENCES `transactions` (`transactionID`) ON DELETE CASCADE;

--
-- Constraints for table `users_device_history`
--
ALTER TABLE `users_device_history`
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`userId`) REFERENCES `users` (`masterUserId`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
